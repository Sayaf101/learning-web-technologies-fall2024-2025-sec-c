-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 21, 2025 at 04:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurantmanagementsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `CartID` int(11) NOT NULL,
  `ItemID` int(40) NOT NULL,
  `UserID` int(40) NOT NULL,
  `Quantity` int(40) NOT NULL,
  `Price` decimal(10,5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`CartID`, `ItemID`, `UserID`, `Quantity`, `Price`) VALUES
(25, 1, 10, 1, 500.00000),
(26, 2, 10, 2, 220.00000),
(27, 5, 10, 1, 40.00000),
(28, 2, 10, 2, 220.00000),
(29, 6, 11, 20, 800.00000);

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `ComplaintID` int(11) NOT NULL,
  `CustomerName` varchar(80) NOT NULL,
  `Complaint` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`ComplaintID`, `CustomerName`, `Complaint`) VALUES
(1, 'musa', 'dhhd'),
(2, 'musa a', 'Khabar bhalo na'),
(3, 'musa a', 'Good service');

-- --------------------------------------------------------

--
-- Table structure for table `customerreview`
--

CREATE TABLE `customerreview` (
  `ReviewID` int(11) NOT NULL,
  `ItemID` varchar(10) NOT NULL,
  `UserID` varchar(10) NOT NULL,
  `Review` varchar(500) NOT NULL,
  `Status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customerreview`
--

INSERT INTO `customerreview` (`ReviewID`, `ItemID`, `UserID`, `Review`, `Status`) VALUES
(5, '7', '1', 'moja hoynai', 'Active'),
(6, '', '10', 'Old Stock', 'Inactive'),
(9, '', '10', 'Sour', 'Inactive'),
(10, '', '10', 'spicy', 'Inactive'),
(11, '', '11', 'hi', 'Inactive'),
(12, '', '10', 'yes', 'Inactive'),
(13, '1', '10', 'good', 'Inactive'),
(14, '1', '10', 'good', 'Inactive'),
(15, '', '10', 'd', 'Inactive'),
(16, '1', '10', 'moja', 'Inactive'),
(17, '1', '10', 'moja', 'Inactive'),
(22, '1', '10', 's', 'Inactive');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `ItemID` int(11) NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Category` varchar(100) NOT NULL,
  `Stock` int(40) NOT NULL,
  `Price` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`ItemID`, `ItemName`, `Category`, `Stock`, `Price`) VALUES
(1, 'Komolar Shorbot', 'Drinks', 1, 500),
(2, 'Dal bhat', 'Food', 66, 110),
(3, 'Kala Bhuna', 'Food', 250, 350),
(4, 'Alu Bhorta', 'Food', 35, 30),
(5, 'Dim Bhaji', 'Food', 79, 40),
(6, 'Pepsi', 'Drink', 780, 40),
(7, '7up', 'Drink', 700, 40);

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `NotificationID` int(11) NOT NULL,
  `UserID` int(40) NOT NULL,
  `Notification` varchar(500) NOT NULL,
  `Receiver` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`NotificationID`, `UserID`, `Notification`, `Receiver`) VALUES
(1, 1, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(2, 1, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(3, 1, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(4, 2, 'Our delivery man, Rianul Amin has picked up your order. Please wait for it to arrive', 'Customer'),
(5, 1, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(6, 1, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(7, 2, 'Our delivery man, Rianul Amin has picked up your order. Please wait for it to arrive', 'Customer'),
(8, 1, 'Our delivery man,  has picked up your order. Please wait for it to arrive', 'Customer'),
(9, 1, 'Our delivery man, Rianul Amin has picked up your order. Please wait for it to arrive', 'Customer'),
(10, 2, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(11, 2, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(12, 2, 'Our delivery man, Ratul Khan has picked up your order. Please wait for it to arrive', 'Customer'),
(13, 8, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(14, 8, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(15, 8, 'Our delivery man, Anto Ovi has picked up your order. Please wait for it to arrive', 'Customer'),
(16, 8, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(17, 8, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(18, 8, 'Our delivery man, Ratul Khan has picked up your order. Please wait for it to arrive', 'Customer'),
(19, 8, 'Your order has been delivered successfully. If you have not recieved it yet, file a complaint to admin', 'Customer'),
(20, 1, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(21, 1, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(22, 1, 'Our delivery man, Ratul Khan has picked up your order. Please wait for it to arrive', 'Customer'),
(23, 1, 'Your order has been delivered successfully. If you have not recieved it yet, file a complaint to admin', 'Customer'),
(24, 10, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(25, 10, 'A new order has been placed. Please check order list for details', 'Delivery Man'),
(26, 10, 'Thank you for ordering. We will inform you when a delivery man is assigned.', 'Customer'),
(27, 10, 'A new order has been placed. Please check order list for details', 'Delivery Man');

-- --------------------------------------------------------

--
-- Table structure for table `orderinfo`
--

CREATE TABLE `orderinfo` (
  `OrderID` int(10) NOT NULL,
  `CustomerName` varchar(100) NOT NULL,
  `DeliveryManName` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Bill` decimal(10,0) NOT NULL,
  `DeliveryDate` varchar(80) NOT NULL,
  `OrderDate` varchar(80) NOT NULL,
  `OrderStatus` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderinfo`
--

INSERT INTO `orderinfo` (`OrderID`, `CustomerName`, `DeliveryManName`, `Address`, `Bill`, `DeliveryDate`, `OrderDate`, `OrderStatus`) VALUES
(12, 'musa a', 'N/A', 'mirpur', 7100, 'Not Delivered Yet', '18-01-2025', 'Pending'),
(13, 'musa a', 'N/A', 'mirpur', 1150, 'Not Delivered Yet', '18-01-2025', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `UserID` int(11) NOT NULL,
  `Fullname` varchar(80) NOT NULL,
  `Phone` varchar(80) NOT NULL,
  `Email` varchar(80) NOT NULL,
  `Address` varchar(80) NOT NULL,
  `DOB` varchar(80) NOT NULL,
  `Religion` varchar(80) NOT NULL,
  `Username` varchar(80) NOT NULL,
  `Password` varchar(80) NOT NULL,
  `ProfilePicture` varchar(80) NOT NULL,
  `Role` varchar(80) NOT NULL,
  `Status` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`UserID`, `Fullname`, `Phone`, `Email`, `Address`, `DOB`, `Religion`, `Username`, `Password`, `ProfilePicture`, `Role`, `Status`) VALUES
(1, 'musa', '01738748548', 'm@gmail.com', 'H-2/1 R-4, Rupnagar, Mirpur', '07/10/2001', 'Islam', 'musa', 'mussa12345', 'Uploads/Images/8_orgid_16bd8f72-822d-4278-8601-e1686c5ccca1.jpeg', 'Customer', 'Active'),
(10, 'Bhai Jan', '01567884140', 'b@gmail.com', 'mirpur', '10-10-2010', 'Islam', 'bhaijan', 'bhaijan12345', 'Uploads/Images/8_orgid_16bd8f72-822d-4278-8601-e1686c5ccca1.jpeg', 'Customer', 'Active'),
(11, 'Alam Farhan', '01631343544', 'a@gmail.com', 'Arambag, Dhaka', '15-10-2001', 'Islam', 'alam', 'farhan12345', 'Uploads/Images/default_pfp.png', 'Customer', 'Active'),
(12, 'Fardin Rahman', '01456789123', 'f@gmail.com', 'mirpur 1216', '10-07-1020', 'Islam', 'fardin', 'fardin12345', 'Uploads/Images/fardin.jpeg', 'Admin', 'Active'),
(13, 'Sayaf Nazmus', '01234567891', 's@gmail.com', 'Bashabo', '27-10-2000', 'Islam', 'sayaf', 'sayaf12345', 'Uploads/Images/sayaf.jpeg', 'Manager', 'Active'),
(14, 'Rasfi Akter', '01681898788', 'abi@gmail.com', 'S-12 Uttara', '15-04-1998', 'Islam', 'abiha', 'abiha12345', 'Uploads/Images/default_pfp.png', 'Delivery Man', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`CartID`);

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`ComplaintID`);

--
-- Indexes for table `customerreview`
--
ALTER TABLE `customerreview`
  ADD PRIMARY KEY (`ReviewID`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`ItemID`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`NotificationID`);

--
-- Indexes for table `orderinfo`
--
ALTER TABLE `orderinfo`
  ADD PRIMARY KEY (`OrderID`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `CartID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `ComplaintID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customerreview`
--
ALTER TABLE `customerreview`
  MODIFY `ReviewID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `ItemID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `NotificationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `orderinfo`
--
ALTER TABLE `orderinfo`
  MODIFY `OrderID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

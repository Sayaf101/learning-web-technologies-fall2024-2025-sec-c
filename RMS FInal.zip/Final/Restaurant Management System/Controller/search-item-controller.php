<?php
require_once('../model/menu-model.php');

function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $search = sanitize($_POST['search'] ?? '');

    if (empty($search)) {
        $result = getAllAvailableItem();
    } else {
        $result = searchItem($search);
    }

    if (mysqli_num_rows($result) > 0) {
        echo "
            <table width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
                <tr>
                    <th>Item Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Action</th>
                </tr>
        ";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "
                <tr>
                    <td>{$row['ItemName']}</td>
                    <td>{$row['Category']}</td>
                    <td>{$row['Price']}</td>
                    <td><a href=\"item-page.php?id={$row['ItemID']}\">Show Details and Give Review</a></td>
                </tr>
            ";
        }
        echo "</table>";
    } else {
        echo "<p>No items found matching your search.</p>";
    }
    exit;
}

echo "<p>Error: Invalid request.</p>";
exit;

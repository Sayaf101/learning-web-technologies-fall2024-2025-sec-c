<?php 

require_once('../model/user-info-model.php');

// Sanitize input data to prevent security vulnerabilities
function sanitize($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

$id = $_COOKIE['id'];
$row = userInfo($id);

$fullname = sanitize($_POST['fullname']);
$email = sanitize($_POST['email']);
$phone = sanitize($_POST['phone']);
$address = sanitize($_POST['address']);
$religion = sanitize($_POST['religion']);
$username = sanitize($_POST['username']);

// Error redirection function
function redirectWithError($error) {
    header("location:../view/edit-information.php?err=$error");
    exit();
}

// Validation
if (empty($fullname)) redirectWithError('fullnameEmpty');
if (empty($phone)) redirectWithError('phoneEmpty');
if (empty($email)) redirectWithError('emailEmpty');
if (empty($address)) redirectWithError('addressEmpty');
if (empty($religion)) redirectWithError('religionEmpty');
if (empty($username)) redirectWithError('usernameEmpty');

// Full Name Validation
$namepart = explode(' ', $fullname);
if (count($namepart) < 2 || !preg_match("/^[a-zA-Z-' ]*$/", $fullname)) {
    redirectWithError('fullnameInvalid');
}

// Phone Validation
if (!preg_match("/^01[0-9]{9}$/", $phone)) {
    redirectWithError('phoneInvalid');
}

// Email Validation
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    redirectWithError('emailInvalid');
}
if ($email !== $row['Email'] && !uniqueEmail($email)) {
    redirectWithError('emailExists');
}

// Username Validation
if (!preg_match("/^[a-zA-Z-']*$/", $username)) {
    redirectWithError('usernameInvalid');
}

// Update User Information
if (updateUserInfo($id, $fullname, $email, $phone, $address, $religion, $username) === true) {
    header('location:../view/edit-information.php?success=changed');
    exit();
} else {
    redirectWithError('updateFailed');
}

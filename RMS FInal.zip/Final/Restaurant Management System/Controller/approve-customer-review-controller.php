<?php

    require_once('../Model/customer-review-model.php'); 
    
    $id = $_GET['id'];
    
     if(approveReview($id)) header('location:../view/approve-customer-review.php');

?>
<?php
require_once('../model/user-info-model.php');
session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = [];

    // Validate session
    if (!isset($_SESSION['mail'])) {
        $response['status'] = 'error';
        $response['message'] = 'Session expired. Please sign in again.';
        echo json_encode($response);
        exit();
    }

    // Get user details
    $mail = $_SESSION['mail'];
    $row = getUserByMail($mail); 
    $id = $row['UserID'];

    // Retrieve and sanitize inputs
    $dob = $_POST['dob'] ?? '';
    $dob = date("d-m-Y", strtotime($dob));
    $password = $_POST['password'] ?? '';
    $cpassword = $_POST['cpassword'] ?? '';

    // Validate inputs
    if (empty($dob)) {
        $response['status'] = 'error';
        $response['message'] = 'Date of birth cannot be empty.';
        echo json_encode($response);
        exit();
    }

    if ($dob != $row['DOB']) {
        $response['status'] = 'error';
        $response['message'] = 'Date of birth does not match our records.';
        echo json_encode($response);
        exit();
    }

    if (strlen($password) < 8) {
        $response['status'] = 'error';
        $response['message'] = 'Password must be at least 8 characters long.';
        echo json_encode($response);
        exit();
    }

    if ($password !== $cpassword) {
        $response['status'] = 'error';
        $response['message'] = 'Passwords do not match.';
        echo json_encode($response);
        exit();
    }

    // Update password
    if (changePassword($id, $password) === true) {
        $response['status'] = 'success';
        $response['message'] = 'Password changed successfully.';
        echo json_encode($response);
        exit();
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Failed to change password. Please try again later.';
        echo json_encode($response);
        exit();
    }
}

$response['status'] = 'error';
$response['message'] = 'Invalid request method.';
echo json_encode($response);
?>

<?php
require_once('../model/cart-model.php');
require_once('../model/menu-model.php');

// Set the response content type to JSON
header('Content-Type: application/json');

$itemID = $_GET['id'];
$userID = $_COOKIE['id'];
$row = itemInfo($itemID);

if (!$row) {
    echo json_encode(["status" => "error", "message" => "Item not found."]);
    exit;
}

$price = $row['Price'];
$quantity = $_POST['quantity'];

if (empty($quantity)) {
    echo json_encode(["status" => "error", "message" => "Quantity cannot be empty."]);
    exit;
}

if (is_numeric($quantity)) {
    if ($quantity > 0 && $quantity <= $row['Stock']) {
        // Quantity is valid
    } else {
        echo json_encode(["status" => "error", "message" => "Quantity exceeds available stock."]);
        exit;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid quantity."]);
    exit;
}

$price = (int)$price * (int)$quantity;

$status = addToCart($itemID, $userID, $quantity, $price);
if ($status) {
    $newStock = $row['Stock'] - (int)$quantity;
    updateStock($itemID, $newStock);
    echo json_encode(["status" => "success", "message" => "Item added to cart successfully."]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to add item to cart."]);
}
?>

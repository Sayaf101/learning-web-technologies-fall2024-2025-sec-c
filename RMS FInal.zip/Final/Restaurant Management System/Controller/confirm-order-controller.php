<?php

require_once('../model/user-info-model.php');
require_once('../model/order-info-model.php');
require_once('../model/cart-model.php');
require_once('../model/notification-model.php');

header('Content-Type: application/json');

// Ensure this is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_COOKIE['id'];
    $row = userInfo($id);

    // Retrieve JSON data from the request
    $input = json_decode(file_get_contents('php://input'), true);
    $password = $input['password'];

    if (empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Password cannot be empty.']);
        exit();
    }

    if ($password != $row['Password']) {
        echo json_encode(['status' => 'error', 'message' => 'Password mismatch. Please try again.']);
        exit();
    }

    $customerName = $row['Fullname'];
    $deliveryManName = "N/A";
    $address = $row['Address'];
    $bill = getTotalBill($id);
    $deliveryDate = "Not Delivered Yet";
    $orderDate = date("d-m-Y");
    $orderStatus = "Pending";

    $status = createOrder($customerName, $deliveryManName, $address, $bill, $deliveryDate, $orderDate, $orderStatus);
    if ($status) {
        clearCart($id);
        customerNotification($id, "Thank you for ordering. We will inform you when a delivery man is assigned.", "Customer");
        deliverymanNotification($id, "A new order has been placed. Please check order list for details", "Delivery Man");

        echo json_encode(['status' => 'success', 'message' => 'Order confirmed successfully.']);
        exit();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to confirm the order. Please try again.']);
        exit();
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
    exit();
}

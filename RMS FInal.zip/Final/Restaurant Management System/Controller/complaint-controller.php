<?php

require_once('../model/complaint-model.php');
require_once('../model/user-info-model.php');

// Set the header to JSON for AJAX response
header('Content-Type: application/json');

// Initialize the response array
$response = ['status' => '', 'message' => ''];

// Get the user ID from cookies and fetch user info
$userID = $_COOKIE['id'];
$row = userInfo($userID);

// Retrieve the complaint from the POST request
$complaint = $_POST['complaint'] ?? '';

if (empty($complaint)) {
    $response['status'] = 'error';
    $response['message'] = 'Complaint cannot be empty.';
    echo json_encode($response);
    exit;
}

// Attempt to send the complaint
$status = sendComplaint($row['Fullname'], $complaint);

if ($status) {
    $response['status'] = 'success';
    $response['message'] = 'Complaint posted successfully.';
} else {
    $response['status'] = 'error';
    $response['message'] = 'Failed to post complaint. Please try again.';
}

// Return the response as JSON
echo json_encode($response);
exit;
?>

<?php
require_once('../model/customer-review-model.php');

header('Content-Type: application/json'); // Set response type to JSON

// Debug incoming POST data
error_log('POST Data: ' . print_r($_POST, true)); // Log POST data for debugging

// Validate and retrieve POST data
if (empty($_POST['itemID']) || empty(trim($_POST['review']))) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request. Ensure all required fields are filled.'
    ]);
    exit;
}

// Fetch data from POST
$itemID = $_POST['itemID'];
$id = $_POST['id'];
$review = trim($_POST['review']);

// Validate user ID from cookies
if (!isset($_COOKIE['id']) || empty($_COOKIE['id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'User not authenticated. Please log in.'
    ]);
    exit;
}

$userID = $_COOKIE['id'];
$status = "Inactive"; // Default status for review


$success = postReview($itemID, $userID, $review, $status);

if ($success) {
    echo json_encode(['status' => 'success', 'message' => 'Review posted successfully.']);
    header("Location: ../View/item-page.php?id=" . urlencode($id));
    exit();
    } else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to post review. Please try again.']);
}
?>

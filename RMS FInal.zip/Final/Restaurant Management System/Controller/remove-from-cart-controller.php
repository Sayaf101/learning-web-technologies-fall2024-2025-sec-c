<?php

require_once('../model/menu-model.php'); 
require_once('../model/cart-model.php');

header('Content-Type: application/json'); // Ensure JSON response for AJAX

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['cartID'] ?? null; // Get the cart item ID from the AJAX request

    if (!$id) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Cart ID is required.'
        ]);
        exit();
    }

    $row = getCart($id);
    if (!$row) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Cart item not found.'
        ]);
        exit();
    }

    $itemID = $row['ItemID'];
    $row2 = itemInfo($itemID);
    if (!$row2) {
        echo json_encode([
            'status' => 'error',
            'message' => 'Item details not found.'
        ]);
        exit();
    }

    // Proceed to remove from cart and update stock
    if (removeFromCart($id)) {
        $newStock = $row2['Stock'] + $row['Quantity'];
        $stockUpdated = updateStock($itemID, $newStock);

        if ($stockUpdated) {
            echo json_encode([
                'status' => 'success',
                'message' => 'Item removed from cart and stock updated successfully.'
            ]);
        } else {
            echo json_encode([
                'status' => 'error',
                'message' => 'Item removed from cart, but stock update failed.'
            ]);
        }
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to remove item from cart.'
        ]);
    }
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request.'
    ]);
}

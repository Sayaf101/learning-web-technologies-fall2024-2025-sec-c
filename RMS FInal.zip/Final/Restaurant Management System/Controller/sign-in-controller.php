<?php

session_start();

    require_once('../model/user-info-model.php');

    if(isset($_POST['submit'])){

        $email = $_POST['email'];
        $password = $_POST['password'];

        if(strlen(trim($email)) == 0 || strlen(trim($password)) == 0){

            header('location:../view/sign-in.php?err=empty');
            return;

        }

        $status = login($email, $password);

        if($status!=false){
            if($status['Role'] == "Customer" and $status['Status'] == "Active" ){

                $_SESSION['flag'] = true;
                setcookie("id", $status['UserID'], time()+99999999999, "/");
                header('location:../view/customer-home.php');

            }
            elseif($status['Role'] == "Manager" and $status['Status'] == "Active" ){

                $_SESSION['flag'] = true;
                setcookie("id", $status['UserID'], time()+99999999999, "/");
                header('location:../view/manager-home.php');

            }
            elseif($status['Role'] == "Admin" and $status['Status'] == "Active" ){

                $_SESSION['flag'] = true;
                setcookie("id", $status['UserID'], time()+99999999999, "/");
                header('location:../view/admin-home.php');

            }
           
            else header('location:../view/sign-in.php?err=bannedUser');

        }else header('location:../view/sign-in.php?err=mismatch');
        
    }

?>
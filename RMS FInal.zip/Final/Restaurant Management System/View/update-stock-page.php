<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Stock</title>
    <style>
        .error {
            color: red;
            font-size: 0.9em;
        }
        .success {
            color: green;
            font-size: 0.9em;
        }
    </style>
    <script>
        function validateForm(event) {
            event.preventDefault(); 
            
            let isValid = true;

            const errorMsg = document.getElementById("stockError");
            errorMsg.innerHTML = "";

         
            const stock = document.forms["updateStockForm"]["stock"].value.trim();

            
            if (stock === "") {
                errorMsg.innerHTML = "Stock cannot be empty.";
                isValid = false;
            } else if (!/^\d+$/.test(stock)) {
                errorMsg.innerHTML = "Stock must be a valid positive integer.";
                isValid = false;
            }

         
            if (isValid) {
                document.forms["updateStockForm"].submit();
            }
        }
    </script>
</head>
<body>
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form name="updateStockForm" method="post" action="../controller/update-stock-page-controller.php?id=<?php echo $id; ?>" novalidate autocomplete="off" onsubmit="validateForm(event)">
                    <h1>Update Stock</h1>
                    <br>
                    Stock of <?php echo $row['ItemName']; ?>
                    <input type="text" name="stock" size="43px" value="<?php echo $row['Stock']; ?>">
                    <div id="stockError" class="error"></div>
                    <br><br>
                    <?php if (strlen($success_msg) > 0) { ?>
                        <font class="success"><?= $success_msg ?></font>
                        <br><br>
                    <?php } ?>
                    <button name="submit">Update Stock</button>
                </form>
            </td>
        </tr>
    </table>
</body>
</html>

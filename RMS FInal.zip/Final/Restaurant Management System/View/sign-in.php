<?php

$error_msg = '';

if (isset($_GET['err'])) {

  $err_msg = $_GET['err'];
  
  switch ($err_msg) {
    case 'mismatch': {
        $error_msg = "Wrong email or password.";
        break;
      }
    case 'bannedUser': {
        $error_msg = "Your account is currently banned.";
        break;
      }
      case 'signInFirst': {
        $error_msg = "You need to sign in first.";
        break;
      }
    case 'empty': {
        $error_msg = "Field(s) can not be empty.";
        break;
      }
  }
}

$success_msg = '';

if (isset($_GET['success'])) {

  $s_msg = $_GET['success'];

  switch ($s_msg) {
    case 'created': {
        $success_msg = "Account creation successful. Please sign in.";
        break;
      }
    case 'changed': {
        $success_msg = "Password change successful. Please sign in.";
        break;
      }
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <script>
      function validateForm() {
          const email = document.forms["loginForm"]["email"].value;
          const password = document.forms["loginForm"]["password"].value;

          if (email === "") {
              alert("Email must be filled out");
              return false;
          }

          const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailPattern.test(email)) {
              alert("Please enter a valid email address");
              return false;
          }

          if (password === "") {
              alert("Password must be filled out");
              return false;
          }

          if (password.length < 6) {
              alert("Password must be at least 6 characters long");
              return false;
          }
          return true;
      }
    </script>
   <style>

    body {
    font-family: Arial, sans-serif;
    background-color: #e04b1d;
    margin: 0;
    padding: 0;
    color: #333;
}

header {
        background-color: #e04b1d;
        color: #ffffff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }

    /* Notification Page Styles */
    h1 {
        color: #bf360c;
        font-family: 'Lucida Handwriting', cursive;
        font-size: 36px;
        text-align: center;
        margin-top: 20px;
    }

form {
    max-width: 400px;
    margin: 50px auto;
    background: #ffffff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

.form-group {
    margin-bottom: 15px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

input[type="email"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

input[type="email"]:focus,
input[type="password"]:focus {
    border-color: #d84315;
    outline: none;
    box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
}

button {
    width: 100%;
    background-color: #d84315;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
}

button:hover {
    background-color: #ff7043;
    transform: scale(1.05);
}

a.forgot-password {
    display: block;
    margin-bottom: 20px;
    color: #d84315;
    font-size: 14px;
    text-align: right;
    text-decoration: none;
}

a.forgot-password:hover {
    color: #ff7043;
}

p {
    text-align: center;
    margin-top: 20px;
    font-size: 16px;
    color: #333;
}

</style>

    
</head>
<body>
<?php require 'header.php'; ?>
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
            <form method="post" action="../controller/sign-in-controller.php" novalidate autocomplete="off">
                  <h1>Login Page</h1>
                  <div class="form-group">
                      <label for="email"><b>Email:</b></label>
                      <input type="email" id="email" name="email" placeholder="Enter Your Email">
                  </div>
                  <div class="form-group">
                      <label for="password"><b>Password:</b></label>
                      <input type="password" id="password" name="password" placeholder="Enter Your Password">
                  </div>
                  <a class="forgot-password" href="forgot-password.php">Forgot Password?</a>
                  <?php if (strlen($error_msg) > 0) { ?>
                      <div id="message">
                          <span style="color: red;"><?= $error_msg ?></span>
                      </div>
                  <?php } ?>
                  <?php if (strlen($success_msg) > 0) { ?>
                      <div id="message">
                          <span style="color: green;"><?= $success_msg ?></span>
                      </div>
                  <?php } ?>
                  <button type="submit" name="submit">Login</button>
                  
              </form>

                    <hr width="auto">
                    Don't have an account?
                    <br><br>
                    <a href="sign-up.php"><button>Register</button></a>
            </td>
        </tr>
    </table>
    <?php require 'footer.php'; ?>
</body>
</html>
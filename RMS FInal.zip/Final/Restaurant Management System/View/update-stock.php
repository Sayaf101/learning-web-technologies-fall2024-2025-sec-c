<?php
session_start();
if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signIn');
    require_once('../Model/Menu-model.php');
  
    $result = getAllItem();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Stock</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        h1 {
            color: #333;
        }
        table {
            width: 85%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: #fff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:hover {
            background-color: #f2f2f2;
        }
        .action-link {
            color: #007bff;
            text-decoration: none;
        }
        .action-link:hover {
            text-decoration: underline;
        }
        .empty-msg {
            text-align: center;
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
<br><br>
    <center><h1>Menu</h1>
    <?php 
           
        if(mysqli_num_rows($result)>0){
            echo" <table width=\"85%\" cellspacing=\"0\" cellpadding=\"15\">
        <tr>
            <td>
                Item ID
            </td>
            <td>
                Item Name
            </td>
            <td>
                Stock
            </td>
            <td>
                Action
            </td>
            <hr width=auto><br>
        </tr>";
            while($w=mysqli_fetch_assoc($result)){
                $itemid=$w['ItemID'];
                $name=$w['ItemName'];
                $stock=$w['Stock'];
                echo "    
                <tr><td>$itemid</td>
                <td>$name</td>
                <td>$stock</td>
                <td><a href=\"update-stock-page.php?id={$itemid}\">Update Stock</a></td>     
                </tr>";
            }
        }else{
                echo"<tr><td align=\"center\">Menu is empty.</td></tr>";
            }
    ?>
    </table>
    </center>
</body>
</html>
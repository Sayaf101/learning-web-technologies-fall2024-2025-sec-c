<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
        /* General Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            color: #333;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }

        h3 {
            text-align: center;
            margin-top: 30px;
            font-size: 28px;
            color: #d4a373;
        }

        hr {
            border: 0;
            height: 2px;
            background: #d4a373;
            margin: 20px auto;
            width: 80%;
        }

        /* Container for Content */
        .container {
            max-width: 800px;
            margin: 20px auto;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            border-radius: 8px;
        }

        .content {
            text-align: center;
            margin: 20px 0;
        }

        b {
            font-size: 18px;
            color: #555;
        }

        p {
            margin: 10px 0;
            color: #666;
        }

        /* Address and Phone */
        .info {
            margin: 15px 0;
        }

        .info p {
            font-size: 16px;
        }
    </style>
</head>
<body>

<h3>About Us</h3>
<hr>
<div class="container">
    <div class="info">
        <b>Address:</b>
        <p>Level - 8, Jamuna Future Park, Basundhara, Dhaka 12</p>
        <b>Phone:</b>
        <p>01738748548</p>
    </div>
    <div class="content">
        <p>
            At Izakaya, we are dedicated to crafting extraordinary dining experiences for our guests. 
        </p>
        <p>
            Established in 2012, we have set out on a culinary journey to bring the finest flavors, 
            exceptional service, and a welcoming ambiance to your table.
        </p>
        <p>
            Thank you for choosing our restaurant.
        </p>
    </div>
</div>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['mail'])) {
    header('location:forgot-password.php?err=accessDenied');
    exit();
}

$error_msg = '';

if (isset($_GET['err'])) {
    switch ($_GET['err']) {
        case 'empty':
            $error_msg = "Please enter your date of birth.";
            break;
        case 'dobError':
            $error_msg = "The date of birth does not match our records.";
            break;
        case 'invalid':
            $error_msg = "Password must be at least 8 characters long.";
            break;
        case 'mismatch':
            $error_msg = "Passwords do not match.";
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Reset your password securely by verifying your date of birth.">
    <title>Change Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e04b1d;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #e04b1d;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #bf360c;
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
        }

        p {
            text-align: center;
            margin-bottom: 20px;
            font-size: 16px;
            color: #333;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="date"], 
        input[type="password"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="date"]:focus,
        input[type="password"]:focus {
            border-color: #d84315;
            outline: none;
            box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
        }

        button {
            width: 100%;
            background-color: #d84315;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        .error {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-bottom: 10px;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 10px;
            color: #d84315;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            color: #ff7043;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php require 'header.php'; ?>
    <div class="container">
        <form method="post" action="../controller/change-password-controller.php" novalidate autocomplete="off">
            <h1>Create New Password</h1>
            <p>To reset your password, please verify your date of birth and provide a new password.</p>
            <label for="dob">Enter Date of Birth:</label>
            <input type="date" id="dob" name="dob" required>
            
            <label for="password">New Password:</label>
            <input type="password" id="password" name="password" minlength="8" required>
            
            <label for="cpassword">Confirm New Password:</label>
            <input type="password" id="cpassword" name="cpassword" minlength="8" required>
            
            <?php if ($error_msg): ?>
                <p class="error"><?= htmlspecialchars($error_msg) ?></p>
            <?php endif; ?>
            
            <button type="submit" name="submit">Change Password</button>
            <a href="forgot-password.php">Go Back</a>
        </form>
    </div>
    <?php require 'footer.php'; ?>
</body>
</html>

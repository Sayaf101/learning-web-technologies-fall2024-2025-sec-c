<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
require_once('../model/menu-model.php');
require_once('../model/user-info-model.php');
require_once('../model/customer-review-model.php');

$userid = $_COOKIE['id'];
$id = $_GET['id'];
$row = itemInfo($id);

$result = getAllReview($id);

$error_msg = '';

if (isset($_GET['err'])) {
    $err_msg = $_GET['err'];
    switch ($err_msg) {
        case 'empty': {
                $error_msg = "Please type something first.";
                break;
            }
    }
}

$success_msg = '';

if (isset($_GET['success'])) {
    $s_msg = $_GET['success'];
    switch ($s_msg) {
        case 'posted': {
                $success_msg = "Review is pending for manager approval.";
                break;
            }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Item Details & Review Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color:#e04b1d;
            color: white;
            padding: 10px 20px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #d84315;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
            text-align: center;
            margin: 20px 0;
        }

        table {
            margin: 50px auto;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        td {
            padding: 20px;
            font-size: 18px;
            line-height: 1.6;
        }

        textarea {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea:focus {
            border-color: #d84315;
            outline: none;
            box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
        }

        button {
            background-color: #d84315;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        a {
            text-decoration: none;
            color: #d84315;
            font-size: 16px;
            margin-top: 15px;
            display: inline-block;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #ff7043;
        }

        font {
            display: block;
            margin-top: 10px;
            font-size: 14px;
        }

        font[align="center"] {
            text-align: center;
            display: block;
        }

        font[color="red"] {
            color: #d84315;
            font-weight: bold;
        }

        font[color="green"] {
            color: #4caf50;
            font-weight: bold;
        }
        a {
            display: block;
            text-align: center;
            margin: 20px auto;
            width: 200px;
            padding: 10px;
            font-size: 18px;
            color: #ffffff;
            background-color: #d84315;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        a:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

    </style>
    
</head>

<body>
    <?php require 'header.php'; ?>
    <h1>Item Details & Review Page</h1>
    <table width="50%">
        <tr>
            <td>
                <h3><?php echo $row['ItemName']; ?></h3>
                <b>Category : </b><?php echo $row['Category']; ?>
                <br><br>
                <b>Price :</b> <?php echo $row['Price']; ?>
                <br><br>
                <center><a href="add-to-cart.php?id=<?php echo $row['ItemID']; ?>">Add To Cart</a></center>
            </td>
        </tr>
    </table>
    <table width="50%">
        <tr>
            <td>
                <h1>Review</h1>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($w = mysqli_fetch_assoc($result)) {
                        $uid = $w['UserID'];
                        $rid = $w['ReviewID'];
                        $name = getUsernameByID($uid);
                        $review = $w['Review'];
                        echo "<b>{$name} : </b> {$review}<br>";
                        if ($userid == $uid) {
                            echo "<br><a href=\"../controller/delete-review-controller.php?rid={$rid}&id={$id}\">Delete Review</a><br><br>";
                        }
                        echo "<br>";
                    }
                }
                ?>
                <form method="post" action="../controller/post-review-controller.php" novalidate autocomplete="off">
                    <input type="hidden" name="id" value=<?=$id?>>
                    <input type="hidden" name="itemID" value="<?= htmlspecialchars($row['ItemID'], ENT_QUOTES, 'UTF-8') ?>">
                    <textarea rows="5" name="review" placeholder="Write your review..."></textarea><br><br>
                    <button type="submit" name="submit">Post Review</button>
                </form>

                <?php if (isset($_GET['success']) && $_GET['success'] == 'reviewPosted'): ?>
                    <font color="green" align="center">Review posted successfully.</font>
                <?php endif; ?>


                
            </td>
        </tr>
    </table>
    <a href="menu.php">Go Back</a>
    <?php require 'footer.php'; ?>
</body>

</html>

<?php
session_start();
if(!isset($_COOKIE['flag'])) header('location:sign-in.php?err=accessDenied');
    require_once('../Model/user-info-model.php');
  
    $result = getAllResignApplicant();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Resign Application</title>
    <link rel="stylesheet" href="CSS/mystyle.css">
    <link rel="stylesheet" href="CSS/allbg.css">
</head>
<body>
<?php require_once('header.php');?>
    <br><br>
    <center><h1>Manage Resign Application</h1>
    <?php
            if(mysqli_num_rows($result)>0){
               echo"<table width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
            <tr>
                <td>
                    Name
                </td>
                <td>
                    Phone
                </td>
                <td>
                    Email
                </td>
                <td colspan=2>
                    Action
                </td>
                <hr width=auto><br>
            </tr>";
                while($w=mysqli_fetch_assoc($result)){
                    $id = $w['UserID'];
                    $name = $w['Fullname'];
                    $phone = $w['Phone'];
                    $email = $w['Email'];
                    echo "<tr><td>$name</td>
                    <td>$phone</td>
                    <td>$email</td> 
                    <<td><a href=\"../Controller/approve-resign-application-controller.php?id={$id}\">Approve</a></td>
                    <td><a href=\"../Controller/reject-resign-application-controller.php?id={$id}\">Reject</a></td>          
                    </tr>";
                }
            }else{
                echo"<tr><td align=\"center\">No Pending Applications.</td></tr>";
            }
        ?>
        </table>
        </center>
        <?php require_once('footer.php');?>
</body>
</html>
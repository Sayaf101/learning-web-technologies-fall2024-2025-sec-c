<?php

$error_msg = '';

if (isset($_GET['err'])) {

  $err_msg = $_GET['err'];
  
  switch ($err_msg) {
    case 'notFound': {
        $error_msg = "Email does not exist in our database.";
        break;
      }
      case 'accessDenied': {
        $error_msg = "Please provide an email first.";
        break;
      }
    case 'empty': {
        $error_msg = "Email can not be empty.";
        break;
      }
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e04b1d;
            margin: 0;
            padding: 0;
            color: #333;
        }

        header {
            background-color: #e04b1d;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 24px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        form {
            max-width: 400px;
            margin: 50px auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #bf360c;
            text-align: center;
            font-size: 28px;
            margin-bottom: 20px;
        }

        input[type="email"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        input[type="email"]:focus {
            border-color: #d84315;
            outline: none;
            box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
        }

        button {
            width: 100%;
            background-color: #d84315;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #d84315;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            color: #ff7043;
        }

        .error-message {
            color: red;
            font-size: 14px;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<?php require 'header.php'; ?>
    
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="../controller/forgot-password-controller.php" novalidate autocomplete="off">
                    <h1>Password Assistance</h1>
                    Email
                    <input type="email" name="email" size="43px">
                    <?php if (strlen($error_msg) > 0) { ?>
                        <br><br>
                        <font color="red" align="center"><?= $error_msg ?></font>
                    <?php } ?>
                    <br><br>
                    <button name="submit">Continue</button>
                    <a href="sign-in.php">Go Back</a>
                </form>
            </td>
        </tr>
    </table>

    <?php require 'footer.php'; ?>

</body>
</html>
<?php 
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complaint</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#complaintForm').on('submit', function (e) {
                e.preventDefault(); // Prevent the default form submission

                // Clear previous messages
                $('#error_msg').html('');
                $('#success_msg').html('');

                // Retrieve the complaint input
                const complaint = $('textarea[name="complaint"]').val().trim();

                // Validate input
                if (complaint === '') {
                    $('#error_msg').html('<p style="color: red;">Please type something first.</p>');
                    return;
                }

                // AJAX request
                $.ajax({
                    url: '../controller/complaint-controller.php',
                    type: 'POST',
                    data: { complaint: complaint },
                    dataType: 'json', // Expect JSON response
                    success: function (response) {
                        if (response.status === 'success') {
                            $('#success_msg').html(`<p style="color: green;">${response.message}</p>`);
                            $('textarea[name="complaint"]').val(''); // Clear textarea
                        } else if (response.status === 'error') {
                            $('#error_msg').html(`<p style="color: red;">${response.message}</p>`);
                        }
                    },
                    error: function (xhr, status, error) {
                        console.error('AJAX Error:', error);
                        $('#error_msg').html('<p style="color: red;">An unexpected error occurred. Please try again later.</p>');
                    }
                });
            });
        });
    </script>
    <style>
    /* General Styles */
    body {
        font-family: 'Georgia', serif;
        background-color: #fff8e1;
        color: #3e2723;
        margin: 0;
        padding: 0;
    }

    /* Header Styles */
    header {
        background-color: #d84315;
        color: #ffffff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }

    /* Form Container */
    form {
        width: 80%;
        max-width: 800px;
        margin: 30px auto;
        padding: 20px;
        background-color: #ffe0b2;
        border-radius: 12px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: 2px solid #d84315;
        text-align: center;
    }

    form h1 {
        font-family: 'Lucida Handwriting', cursive;
        font-size: 36px;
        color: #bf360c;
        margin-bottom: 20px;
    }

    form textarea {
        width: 90%;
        padding: 10px;
        font-size: 16px;
        border: 2px solid #d84315;
        border-radius: 8px;
        resize: none;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        transition: border-color 0.3s ease;
    }

    form textarea:focus {
        border-color: #ff7043;
        outline: none;
    }

    form button {
        padding: 10px 20px;
        font-size: 18px;
        color: #ffffff;
        background-color: #d84315;
        border: none;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    form button:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    /* Messages */
    #error_msg, #success_msg {
        margin-top: 20px;
        font-size: 16px;
    }

    #error_msg p, #success_msg p {
        margin: 0;
        padding: 10px;
        border-radius: 8px;
        font-weight: bold;
    }

    #error_msg p {
        background-color: #ffcdd2;
        color: #b71c1c;
    }

    #success_msg p {
        background-color: #c8e6c9;
        color: #1b5e20;
    }

    /* Back Button */
    a {
        display: block;
        text-align: center;
        margin: 20px auto;
        width: 200px;
        padding: 10px;
        font-size: 18px;
        color: #ffffff;
        background-color: #d84315;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    a:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    /* Footer Styles */
    footer {
        margin-top: 30px;
        font-size: 16px;
        font-family: 'Georgia', serif;
        text-align: center;
        padding: 10px 0;
        background-color: #d84315;
        color: #ffffff;
    }

    footer p {
        margin: 0;
    }
</style>

</head>
<body>
<?php require 'header.php'; ?>
    <center>
        <form id="complaintForm" method="post" novalidate autocomplete="off">
            <h1>Write a complaint to admin</h1>
            <textarea name="complaint" cols="50" rows="20" placeholder="Type your complaint here..."></textarea><br><br>
            <button type="submit">Submit Complaint</button>
        </form>
        <div id="error_msg"></div>
        <div id="success_msg"></div>
    </center>
    <a href="customer-home.php">Go Back</a>
    <?php require 'footer.php'; ?>
</body>
</html>

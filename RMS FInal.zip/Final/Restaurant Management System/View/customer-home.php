<?php
    session_start();
    if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
    require_once('../model/user-info-model.php');

    $id = $_COOKIE['id'];
    $row = userInfo($id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Home</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Georgia', serif;
            background-color: #fff8e1;
            color: #3e2723;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #d84315;
            color: #ffffff;
            text-align: center;
            padding: 20px 0;
            font-size: 24px;
            font-family: 'Lucida Handwriting', cursive;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        header h1 {
            margin: 0;
        }

        .profile {
            text-align: right;
            margin: 10px 20px;
            background-color: #ffe0b2;
            padding: 10px;
            border-radius: 8px;
        }

        .profile img {
            border-radius: 50%;
            width: 40px;
            vertical-align: middle;
            border: 2px solid #ffab40;
        }

        .profile a {
            color: #3e2723;
            text-decoration: none;
            margin-left: 15px;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .profile a:hover {
            color: #ffab40;
        }

        .container {
            text-align: center;
            margin: 30px auto;
            width: 70%;
            background: #ffe0b2;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            padding: 30px;
            border-radius: 12px;
            border: 2px solid #d84315;
        }

        .container h1 {
            color: #bf360c;
            margin-bottom: 20px;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
        }

        .button-container {
            display: flex;
            flex-direction: column;
            gap: 15px;
            align-items: center;
        }

        .button-container a {
            display: block;
            width: 200px;
            padding: 10px;
            text-align: center;
            font-size: 18px;
            color: #ffffff;
            background-color: #d84315;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .button-container a:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        footer {
            margin-top: 30px;
            font-size: 16px;
            font-family: 'Georgia', serif;
            text-align: center;
            padding: 10px 0;
            background-color: #d84315;
            color: #ffffff;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to Izakaya Restaurant</h1>
    </header>

    <div class="profile">
        <?php echo "<img src=\"../{$row['ProfilePicture']}\" alt=\"Profile Picture\">"; ?>
        <a href="profile.php">Profile</a>
        <a href="../controller/logout-controller.php">Logout</a>
    </div>

    <div class="container">
        <h1>Customer Home</h1>
        <div class="button-container">
            <a href="menu.php">Place Order</a>
            <a href="cart.php">Cart</a>
            <a href="notification.php">Notification</a>
            <a href="order-history.php">Order History</a>
            <a href="menu.php">Review</a>
            <a href="complaint.php">File a Complaint to Admin</a>
        </div>
    </div>

    <?php require 'footer.php'; ?>
</body>
</html>
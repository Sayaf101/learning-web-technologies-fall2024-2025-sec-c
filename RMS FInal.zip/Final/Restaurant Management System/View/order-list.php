<?php
session_start();
if (!isset($_SESSION['flag'])) {
    header('location:sign-in.php?err=signInFirst');
}

require_once('../model/order-info-model.php');
require_once('../model/user-info-model.php');

$id = $_COOKIE['id']; // Assuming delivery man ID is stored in cookie
$row = userInfo($id);
$fullname = $row['Fullname'];
$availableOrders = getAvailableOrders();

// Handling form submission for taking an order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $orderId = $_POST['order_id'];
    $result = assignOrderToDeliveryMan($orderId, $id);

    if ($result) {
        echo "<script>alert('Order assigned successfully!'); window.location.reload();</script>";
    } else {
        echo "<script>alert('Failed to assign order!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order List</title>
</head>
<body>
<?php require 'header.php'; ?>
    <br><br>
    <a href="notification.php" 
   style="
       display: inline-block; 
       text-decoration: none; 
       background-color: #007bff; 
       color: white; 
       margin:5px;
       padding: 10px 20px; 
       border-radius: 5px; 
       position: absolute; 
       top: 10px; 
       right: 10px; 
       font-family: Arial, sans-serif; 
       font-size: 14px; 
       box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1); 
       transition: background-color 0.3s ease;">
   Notification
</a>

    <center>
        <h1 style="color:green">Available Orders</h1>
        <?php
        if (mysqli_num_rows($availableOrders) > 0) {
            echo "<table width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
                <tr>
                    <td><b>Order ID</b></td>
                    <td><b>Customer Name</b></td>
                    <td><b>Delivery Address</b></td>
                    <td><b>Bill</b></td>
                    <td><b>Order Date</b></td>
                    <td><b>Action</b></td>
                </tr>";
            while ($order = mysqli_fetch_assoc($availableOrders)) {
                echo "
                <tr>
                    <td>{$order['OrderID']}</td>
                    <td>{$order['CustomerName']}</td>
                    <td>{$order['Address']}</td>
                    <td>{$order['Bill']}</td>
                    <td>{$order['OrderDate']}</td>
                    <td>
                        <form method=\"post\">
                            <input type=\"hidden\" name=\"order_id\" value=\"{$order['OrderID']}\">
                            <button type=\"submit\">Take Order</button>
                        </form>
                    </td>
                </tr>";
            }
            echo "</table>";
        } else {
            echo "<h3>No Available Orders</h3>";
        }
        ?>
        <a href="sign-in.php">Go Back</a>
    </center>
<?php require 'footer.php'; ?>
</body>
</html>

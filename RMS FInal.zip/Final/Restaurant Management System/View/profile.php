<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Georgia', serif;
            background-color: #fff8e1;
            color: #3e2723;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #e04b1d;
            color: #ffffff;
            text-align: center;
            padding: 20px 0;
            font-size: 24px;
            font-family: 'Lucida Handwriting', cursive;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        header h1 {
            margin: 0;
        }

        table {
            background-color: #ffe0b2;
            margin: 50px auto;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            border: 2px solid #d84315;
        }

        h1 {
            color: #bf360c;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
            margin-bottom: 20px;
        }

        a {
            display: block;
            color: #d84315;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            padding: 10px 0;
            text-align: center;
            transition: color 0.3s ease, transform 0.3s ease;
        }

        a:hover {
            color: #ff7043;
            transform: scale(1.05);
        }

        td {
            text-align: center;
            padding: 30px;
        }

        footer {
            margin-top: 30px;
            font-size: 16px;
            font-family: 'Georgia', serif;
            text-align: center;
            padding: 10px 0;
            background-color: #d84315;
            color: #ffffff;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>
<body>
<?php require 'header.php'; ?>
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
               <h1>Update Your Profile</h1>
                <a href="view-information.php">View Information</a>
                <a href="edit-information.php">Edit Information</a>
                <a href="update-pfp.php">Update Profile Picture</a>
                <a href="update-password.php">Update Password</a>
                <a href="customer-home.php">Go Back</a>
            </td>
        </tr>
    </table>
    <?php require 'footer.php'; ?>
</body>
</html>

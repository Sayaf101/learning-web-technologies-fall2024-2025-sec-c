<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
require_once('../model/user-info-model.php');    

$id = $_COOKIE['id'];
$row = userInfo($id);

$fullnameMsg = $emailMsg = $phoneMsg = $addressMsg = $religionMsg =  $usernameMsg = '';

if (isset($_GET['err'])) {
    $err_msg = $_GET['err'];
    switch ($err_msg) {
        case 'fullnameEmpty': $fullnameMsg = "Fullname can not be empty."; break;
        case 'phoneEmpty': $phoneMsg = "Phone number can not be empty."; break;
        case 'addressEmpty': $addressMsg = "Address can not be empty."; break;
        case 'emailEmpty': $emailMsg = "Email can not be empty."; break;
        case 'dobEmpty': $dobMsg = "Date of birth can not be empty."; break;
        case 'religionEmpty': $religionMsg = "Religion can not be empty."; break;
        case 'usernameEmpty': $usernameMsg = "Username can not be empty."; break;
        case 'fullnameInvalid': $fullnameMsg = "Fullname is not valid."; break;
        case 'phoneInvalid': $phoneMsg = "Phone number is not valid."; break;
        case 'emailInvalid': $emailMsg = "Email is not valid."; break;
        case 'emailExists': $emailMsg = "Email already exists."; break;
        case 'usernameInvalid': $usernameMsg = "Username is not valid."; break;
    }
}

$success_msg = '';

if (isset($_GET['success'])) {
    $s_msg = $_GET['success'];
    if ($s_msg === 'changed') $success_msg = "Information successfully updated.";
}
?>  

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Information</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background-color: #fff8e1;
            color: #3e2723;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #e04b1d;
            color: #ffffff;
            text-align: center;
            padding: 20px 0;
            font-size: 24px;
            font-family: 'Lucida Handwriting', cursive;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: #bf360c;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
            text-align: center;
            margin: 20px 0;
        }

        table {
            background-color: #ffe0b2;
            margin: 20px auto;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            border: 2px solid #d84315;
            width: 70%;
        }

        td {
            padding: 20px;
        }

        input[type="text"],
        input[type="email"],
        select {
            width: 95%;
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #d84315;
            border-radius: 8px;
            font-size: 16px;
        }

        button {
            background-color: #d84315;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 10px;
            display: inline-block;
        }

        button:hover {
            background-color: #ff7043;
        }

        a {
            display: inline-block;
            text-decoration: none;
            color: white;
            background-color: #d84315;
            padding: 10px 20px;
            border-radius: 8px;
            margin-top: 10px;
            font-size: 18px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        a:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        font {
            font-size: 14px;
        }

        .success {
            color: green;
            font-weight: bold;
        }

        .error {
            color: red;
            font-size: 14px;
        }
    </style>
    <script>
    function validateEditForm() {
        const form = document.forms["editInformationForm"];
        const fullname = form["fullname"].value.trim();
        const phone = form["phone"].value.trim();
        const email = form["email"].value.trim();
        const address = form["address"].value.trim();
        const religion = form["religion"].value;
        const username = form["username"].value.trim();

        const phonePattern = /^[0-9]{10,15}$/; 
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (fullname === "") {
            alert("Full Name cannot be empty.");
            return false;
        }

        if (phone === "") {
            alert("Phone Number cannot be empty.");
            return false;
        } else if (!phonePattern.test(phone)) {
            alert("Phone Number is not valid. It must contain 10-15 digits.");
            return false;
        }

        if (email === "") {
            alert("Email cannot be empty.");
            return false;
        } else if (!emailPattern.test(email)) {
            alert("Email is not valid.");
            return false;
        }

        if (address === "") {
            alert("Address cannot be empty.");
            return false;
        }

        if (religion === "Not Selected") {
            alert("Please select your Religion.");
            return false;
        }

        if (username === "") {
            alert("Username cannot be empty.");
            return false;
        }

        return true; 
    }
    </script>
</head>
<body>
<?php require 'header.php'; ?>
<h1>Edit Information</h1>
<table>
    <tr>
        <td>
            <form method="post" action="../controller/edit-information-controller.php" novalidate autocomplete="off" name="editInformationForm" onsubmit="return validateEditForm();">
                <b>Full Name:</b>
                <input type="text" name="fullname" value="<?php echo "{$row['Fullname']}"; ?>">
                <?php if ($fullnameMsg) echo "<div class='error'>{$fullnameMsg}</div>"; ?>
                <br><br>

                <b>Phone Number:</b>
                <input type="text" name="phone" value="<?php echo "{$row['Phone']}"; ?>">
                <?php if ($phoneMsg) echo "<div class='error'>{$phoneMsg}</div>"; ?>
                <br><br>

                <b>Email:</b>
                <input type="email" name="email" value="<?php echo "{$row['Email']}"; ?>">
                <?php if ($emailMsg) echo "<div class='error'>{$emailMsg}</div>"; ?>
                <br><br>

                <b>Address:</b>
                <input type="text" name="address" value="<?php echo "{$row['Address']}"; ?>">
                <?php if ($addressMsg) echo "<div class='error'>{$addressMsg}</div>"; ?>
                <br><br>

                <b>Religion:</b>
                <select name="religion">
                    <option disabled selected hidden value="Not Selected">Choose Your Religion</option>
                    <option value="Islam" <?php if ($row['Religion'] == "Islam") echo "selected"; ?>>Islam</option>
                    <option value="Hindu" <?php if ($row['Religion'] == "Hindu") echo "selected"; ?>>Hindu</option>
                    <option value="Christian" <?php if ($row['Religion'] == "Christian") echo "selected"; ?>>Christian</option>
                </select>
                <?php if ($religionMsg) echo "<div class='error'>{$religionMsg}</div>"; ?>
                <br><br>

                <b>Username:</b>
                <input type="text" name="username" value="<?php echo "{$row['Username']}"; ?>">
                <?php if ($usernameMsg) echo "<div class='error'>{$usernameMsg}</div>"; ?>
                <br><br>

                <?php if ($success_msg) echo "<div class='success'>{$success_msg}</div>"; ?>
                <br><br>

                <button type="submit">Update Information</button>
                <a href="profile.php">Go Back</a>
            </form>
        </td>
    </tr>
</table>
<?php require 'footer.php'; ?>
</body>
</html>

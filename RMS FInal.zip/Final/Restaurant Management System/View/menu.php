<?php
session_start();
if (!isset($_SESSION['flag'])) {
    header('location:sign-in.php?err=signInFirst');
    exit;
}
require_once('../model/user-info-model.php');

// Retrieve user data
$id = $_COOKIE['id'];
$row = userInfo($id); // Fetch user information from the database
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Menu</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Georgia', serif;
            background-color: #fff8e1;
            color: #3e2723;
            margin: 0;
            padding: 0;
        }

        /* Header Styles */
        header {
            background-color: #d84315;
            color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 10px 20px;
        }

        .logo img {
            height: 50px;
            width: auto;
            border-radius: 8px;
        }

        .title h1 {
            font-family: 'Lucida Handwriting', cursive;
            font-size: 32px;
            margin: 0;
            text-align: center;
        }

        /* Profile Links */
        .profile-links {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-left: auto; /* Ensures the entire section is pushed to the right */
            padding-right: .25px; /* Adds some space between the links and the edge of the header */
        }

        .profile-links img {
            border-radius: 50%;
            height: 40px;
            width: 40px;
            border: 2px solid #ffab40;
        }

        .profile-links a {
            color: #ffffff;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .profile-links a:hover {
            color: #ff7043;
        }


        /* Menu Header */
        #menuHeader {
            text-align: center;
            color: #bf360c;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
            margin: 20px 0;
        }

        /* Search Bar */
        form {
            text-align: center;
            margin: 20px 0;
        }

        #searchInput {
            width: 60%;
            padding: 10px;
            font-size: 16px;
            border: 2px solid #d84315;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: border-color 0.3s ease;
        }

        #searchInput:focus {
            border-color: #ff7043;
            outline: none;
        }

        /* Menu Container */
        #menuContainer {
            width: 80%;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffe0b2;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            border: 2px solid #d84315;
            text-align: center;
        }

        #menuContainer p {
            font-size: 18px;
            color: #3e2723;
        }

        /* Back Button */
        a {
            display: block;
            text-align: center;
            margin: 20px auto;
            width: 200px;
            padding: 10px;
            font-size: 18px;
            color: #ffffff;
            background-color: #d84315;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        a:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        /* Footer */
        footer {
            margin-top: 30px;
            font-size: 16px;
            font-family: 'Georgia', serif;
            text-align: center;
            padding: 10px 0;
            background-color: #d84315;
            color: #ffffff;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-container">
            <!-- Logo -->
            <div class="logo">
            <img src="../Assets/logo.png" alt="Izakaya Logo">

            </div>

            <!-- Title -->
            <div class="title">
                <h1>Welcome to Izakaya Restaurant</h1>
            </div>

            <!-- Profile Links -->
            <div class="profile-links">
                <!-- Dynamic Profile Picture -->
                <img src="../<?php echo htmlspecialchars($row['ProfilePicture']); ?>" alt="Profile Picture">
                <a href="profile.php">Profile</a>
                <a href="../controller/logout-controller.php">Logout</a>
            </div>
        </div>
    </header>

    <!-- Menu Content -->
    <h1 id="menuHeader">Menu</h1>
    <form>
        <input 
            type="text" 
            id="searchInput" 
            name="search" 
            placeholder="Search Items by Name" 
            onkeyup="ajaxSearch()"
        />
    </form>
    <div id="menuContainer">
        <!-- Dynamic content will be loaded here -->
        <p>Loading menu items...</p>
    </div>
    <a href="customer-home.php">Go Back</a>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 Izakaya Restaurant. All Rights Reserved.</p>
    </footer>

    <script>
        function ajaxSearch() {
            let searchValue = document.getElementById('searchInput').value;
            let xhttp = new XMLHttpRequest();

            xhttp.open('POST', '../controller/search-item-controller.php', true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send('search=' + encodeURIComponent(searchValue));

            xhttp.onreadystatechange = function () {
                if (this.readyState === 4 && this.status === 200) {
                    document.getElementById('menuContainer').innerHTML = this.responseText;
                }
            };
        }

        // Load all items initially
        window.onload = function () {
            ajaxSearch();
        };
    </script>
</body>
</html>

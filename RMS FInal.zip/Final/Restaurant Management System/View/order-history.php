<?php

session_start();
if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');

    require_once('../model/order-info-model.php');
    require_once('../model/user-info-model.php');
  
    $id = $_COOKIE['id'];
    $row = userInfo($id);
    $fullname = $row['Fullname'];
    $result = getOrderHistory($fullname);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order History</title>
    <style>
    /* General Styles */
    body {
        font-family: 'Georgia', serif;
        background-color: #fff8e1;
        color: #3e2723;
        margin: 0;
        padding: 0;
    }

    /* Header Styles */
    header {
        background-color: #e04b1d;
        color: #ffffff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
    }

    /* Order History Page Styles */
    h1 {
        color: #bf360c;
        font-family: 'Lucida Handwriting', cursive;
        font-size: 36px;
        text-align: center;
        margin-top: 20px;
    }

    /* Order History Table */
    table {
        width: 85%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: #fff;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 12px;
        overflow: hidden;
    }

    table th, table td {
        padding: 15px;
        text-align: left;
        font-size: 16px;
        color: #3e2723;
        border: 1px solid #ffe0b2; /* Light border for cells */
    }

    table th {
        background-color: #ffcc80;
        font-weight: bold;
    }

    table tr:nth-child(even) {
        background-color: #fff3e0; /* Light alternate row color */
    }

    table tr:nth-child(odd) {
        background-color: #ffffff;
    }

    /* No Order History Message */
    table tr td[colspan] {
        text-align: center;
        font-size: 18px;
        color: #888;
    }

    /* Back Button */
    a {
        display: block;
        text-align: center;
        margin: 20px auto;
        width: 200px;
        padding: 10px;
        font-size: 18px;
        color: #ffffff;
        background-color: #d84315;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    a:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    /* Footer Styles */
    footer {
        margin-top: 30px;
        font-size: 16px;
        font-family: 'Georgia', serif;
        text-align: center;
        padding: 10px 0;
        background-color: #d84315;
        color: #ffffff;
    }

    footer p {
        margin: 0;
    }
</style>

</head>
<body>
<?php require 'header.php'; ?>
    <br><br>
    <center><h1>Order History</h1>
    <?php 
           
            if(mysqli_num_rows($result)>0){
               echo" <table width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
            <tr>
                <td>
                    <b>Customer Name</b>
                </td>
                <td>
                    <b>Delivery Man Name</b>
                </td>
                <td>
                    <b>Delivery Address</b>
                </td>
                <td>
                    <b>Bill</b>
                </td>
                <td>
                    <b>Delivery Date</b>
                </td>
                <td>
                    <b>Order Date</b>
                </td>
                <hr width=auto><br>
            </tr>";
                while($w=mysqli_fetch_assoc($result)){
                    $customerName=$w['CustomerName'];
                    $deliverymanName=$w['DeliveryManName'];
                    $address=$w['Address'];
                    $bill=$w['Bill'];
                    $ddate=$w['DeliveryDate'];
                    $odate=$w['OrderDate'];
                    echo "    
                    <tr><td>$customerName</td>
                    <td>$deliverymanName</td>
                    <td>$address</td> 
                    <td>$bill</td>
                    <td>$ddate</td> 
                    <td>$odate</td>      
                    </tr>";
                }
            }else{
                echo"<tr><td align=\"center\">No Order History Found</td></tr>";
            }
        ?>
        </table>
        </center>
        <a href="customer-home.php">Go Back</a>
        <?php require 'footer.php'; ?>
</body>
</html>
<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
require_once('../model/cart-model.php');
require_once('../model/menu-model.php');

$id = $_COOKIE['id'];
$result = cartInfo($id);
$flag = 0;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <script>
        // JavaScript for handling the Remove from Cart action via AJAX
        function removeFromCart(cartID) {
            if (confirm('Are you sure you want to remove this item from the cart?')) {
                fetch('../controller/remove-from-cart-controller.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ cartID: cartID }),
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert(data.message);
                        document.getElementById(`cart-item-${cartID}`).remove(); // Remove the row from the table
                        // Check if the table is empty after removing an item
                        if (document.querySelectorAll('tr.cart-item').length === 0) {
                            document.getElementById('cart-table').innerHTML = '<tr><td align="center">No Item Found</td></tr>';
                            document.getElementById('confirm-order-link').style.display = 'none'; // Hide Confirm Order link
                        }
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while removing the item.');
                });
            }
        }
    </script>
    <style>
    /* General Styles */
    body {
        font-family: 'Georgia', serif;
        background-color: #fff8e1;
        color: #3e2723;
        margin: 0;
        padding: 0;
    }

    /* Header Styles */
   
    /* Header Styles */
    header {
        background-color: #e04b1d; /* Lighter shade of orange for a softer look */
        color: #ffffff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Reduced shadow intensity */
        position: sticky;
        top: 0;
        z-index: 1000;
        padding: 15px 0;
    }

    .header-container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    .logo img {
        height: 45px;
        width: auto;
        border-radius: 6px; /* Slightly smaller and subtler */
    }

    .title h1 {
        font-family: 'Lucida Handwriting', cursive;
        font-size: 28px; /* Reduced size for subtler presence */
        margin: 0;
        text-align: center;
        font-weight: normal; /* Lighter font weight */
    }

    .profile-links {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .profile-links img {
        border-radius: 50%;
        height: 35px; /* Reduced profile icon size */
        width: 35px;
        border: 2px solid #ffd54f; /* Softer highlight around profile images */
    }

    .profile-links a {
        color: #ffffff;
        text-decoration: none;
        font-size: 14px; /* Slightly smaller font size */
        font-weight: normal; /* Subtler font weight */
        transition: color 0.3s ease;
    }

    .profile-links a:hover {
        color: #ffe082; /* Softer hover effect */
    }
    
    h1 {
        color: #d84315;
        font-family: 'Lucida Handwriting', cursive;
        font-size: 36px;
        margin: 20px 0;
        text-align: center;
    }

    table {
        width: 85%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: #fff;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        overflow: hidden;
    }

    th, td {
        padding: 15px;
        text-align: center;
        font-size: 16px;
        color: #555;
        border: 1px solid #e0e0e0;
    }

    th {
        background-color: #d84315;
        color: #ffffff;
        font-size: 18px;
    }

    tr:nth-child(even) {
        background-color: #f9f9f9;
    }

    tr:nth-child(odd) {
        background-color: #fff;
    }

    button {
        background-color: #d84315;
        color: #ffffff;
        padding: 8px 15px;
        font-size: 14px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    button:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    /* Link Styles */
    a {
        display: inline-block;
        margin: 20px auto;
        padding: 10px 20px;
        background-color: #d84315;
        color: #ffffff;
        text-decoration: none;
        border-radius: 8px;
        font-size: 18px;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    a:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    #confirm-order-link {
        margin-top: 15px;
    }

    /* Empty Cart Message */
    #cart-table td {
        text-align: center;
        font-size: 18px;
        color: #888;
    }

    /* Footer Styles */
    footer {
        margin-top: 30px;
        text-align: center;
        padding: 10px 0;
        background-color: #d84315;
        color: #ffffff;
        font-size: 14px;
        border-top: 2px solid #b71c1c;
        box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
    }

    footer p {
        margin: 5px 0;
    }

    footer a {
        color: #ffcc80;
        text-decoration: none;
        font-weight: bold;
        transition: color 0.3s ease;
    }

    footer a:hover {
        color: #ffffff;
    }
    cart-table {
        width: 85%;
        margin: 20px auto;
        border-collapse: collapse;
        background-color: #fff8e1; /* Light beige for a warm look */
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
        border-radius: 12px; /* Rounded corners */
        overflow: hidden;
        padding: 15px; /* Added padding for spacing */
    }

    #cart-table th,
    #cart-table td {
        padding: 15px;
        text-align: center;
        font-size: 16px;
        color: #3e2723; /* Dark brown for readability */
        border: 1px solid #ffe0b2; /* Light border for a polished look */
    }

    #cart-table th {
        background-color: #ef6c00; /* Soft orange for header row */
        color: #ffffff; /* White text for contrast */
        font-size: 18px;
    }

    #cart-table tr:nth-child(even) {
        background-color: #fff3e0; /* Very light orange for alternating rows */
    }

    #cart-table tr:nth-child(odd) {
        background-color: #fff; /* White for alternating rows */
    }

    /* Empty Cart Message */
    #cart-table td {
        text-align: center;
        font-size: 18px;
        color: #888; /* Neutral gray for empty cart message */
    }

    /* General Background Styling for the Cart Section */
    #cart-section {
        background-color: #fbe9e7; /* Light peach background */
        border: 2px solid #ef6c00; /* Orange border for emphasis */
        border-radius: 12px; /* Rounded corners */
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Deeper shadow for focus */
        padding: 30px; /* Padding around the content */
        width: 90%;
        margin: 20px auto;
        text-align: center;
    }

    #cart-section h1 {
        color: #bf360c; /* Darker orange for the title */
        font-family: 'Lucida Handwriting', cursive;
        font-size: 36px;
        margin-bottom: 20px;
    }

    #confirm-order-link {
        margin-top: 20px;
    }
</style>

</head>

<body>
    <?php require 'header.php'; ?>
    <br><br>
    <center>
        <h1>Cart</h1>
        <?php
        if (mysqli_num_rows($result) > 0) {
            echo "<table id=\"cart-table\" width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
                <tr>
                    <td><b>Item Name</b></td>
                    <td><b>Quantity</b></td>
                    <td><b>Price</b></td>
                    <td><b>Action</b></td>
                </tr>";
            while ($w = mysqli_fetch_assoc($result)) {
                $cid = $w['CartID'];
                $id = $w['ItemID'];
                $name = getItemNameByID($id);
                $quantity = $w['Quantity'];
                $price = $w['Price'];
                echo "
                <tr id=\"cart-item-$cid\" class=\"cart-item\">
                    <td>$name</td>
                    <td>$quantity</td>
                    <td>$price</td>
                    <td><button onclick=\"removeFromCart('$cid')\">Remove From Cart</button></td>
                </tr>";
            }
        } else {
            $flag = 1;
            echo "<tr><td align=\"center\">No Item Found</td></tr>";
        }
        ?>
        </table>
        <br><br>
        <?php if ($flag == 0) echo "<a id=\"confirm-order-link\" href=\"confirm-order.php\">Confirm Order & See Total Bill</a>"; ?>
    </center>
    <a href="customer-home.php">Go Back</a>
    <?php require 'footer.php'; ?>
</body>

</html>

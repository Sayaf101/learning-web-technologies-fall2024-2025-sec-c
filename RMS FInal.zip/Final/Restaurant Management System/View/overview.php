<?php
session_start();
if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signIn');
require_once('../Model/user-info-model.php');
require_once('../Model/order-info-model.php');
require_once('../Model/menu-model.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Overview</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        table {
            background-color: #fff;
            border-collapse: collapse;
            width: 50%;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        td {
            padding: 20px;
            text-align: center;
            font-size: 18px;
            border-bottom: 1px solid #ddd;
        }
        td:last-child {
            border-bottom: none;
        }
        td span {
            font-weight: bold;
            color: #007bff;
        }
    </style>
</head>
<body>
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                Number of Customers : <?php echo numberOfCustomer(); ?><br><br>
                Number of Delivery Persons : <?php echo numberOfDeliveryMan(); ?><br><br>
                Number of Items : <?php echo numberOfItem(); ?><br><br>
                Number of Orders : <?php echo numberOfOrder(); ?><br><br>
                Total Revenue : <?php echo totalRevenue(); ?><br>
            </td>
        </tr>
    </table>
</body>
</html>
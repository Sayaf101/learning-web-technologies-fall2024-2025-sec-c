<?php

$fullnameMsg = $emailMsg = $phoneMsg = $addressMsg =  $dobMsg =  $religionMsg =  $usernameMsg = $passwordMsg =  $cpasswordMsg =  '';

if (isset($_GET['err'])) {

  $err_msg = $_GET['err'];
  
  switch ($err_msg) {
    case 'fullnameEmpty': {
        $fullnameMsg = "Fullname can not be empty.";
        break;
      }
    case 'phoneEmpty': {
        $phoneMsg = "Phone number can not be empty.";
        break;
      }
    case 'addressEmpty': {
        $addressMsg = "Address can not be empty.";
        break;
      }
    case 'emailEmpty': {
        $emailMsg = "Email can not be empty.";
        break;
      }
    case 'dobEmpty': {
        $dobMsg = "Date of birth can not be empty.";
        break;
      }
    case 'religionEmpty': {
        $religionMsg = "Religion can not be empty.";
        break;
      }
    case 'usernameEmpty': {
        $usernameMsg = "Username can not be empty.";
        break;
      }
    case 'passwordEmpty': {
        $passwordMsg = "Password can not be empty.";
        break;
      }
    case 'cpasswordEmpty': {
        $cpasswordMsg = "Confirm password can not be empty.";
        break;
      }
    case 'fullnameInvalid': {
        $fullnameMsg = "Fullname is not valid.";
        break;
      }
    case 'phoneInvalid': {
        $phoneMsg = "Phone number is not valid.";
        break;
      }
    case 'emailInvalid': {
        $emailMsg = "Email is not valid.";
        break;
      }
    case 'emailExists': {
        $emailMsg = "Email already exists.";
        break;
      }
    case 'usernameInvalid': {
        $usernameMsg = "Username is not valid.";
        break;
      }
    case 'passwordInvalid': {
        $passwordMsg = "Password is not valid.";
        break;
      }
    case 'passwordMismatch': {
        $cpasswordMsg = "Passwords do not match.";
        break;
      }
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>

    <script>
        function validateForm() {
            const form = document.forms["registrationForm"];
            const fullname = form["fullname"].value.trim();
            const phone = form["phone"].value.trim();
            const email = form["email"].value.trim();
            const address = form["address"].value.trim();
            const dob = form["dob"].value.trim();
            const religion = form["religion"].value;
            const username = form["username"].value.trim();
            const password = form["password"].value;
            const cpassword = form["cpassword"].value;

            if (fullname === "") {
                alert("Full Name cannot be empty.");
                return false;
            }

            const phonePattern = /^[0-9]{10,15}$/;
            if (phone === "") {
                alert("Phone Number cannot be empty.");
                return false;
            } else if (!phonePattern.test(phone)) {
                alert("Phone Number is not valid. It should only contain digits and be between 10 to 15 characters.");
                return false;
            }

            if (email === "") {
                alert("Email cannot be empty.");
                return false;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailPattern.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            if (address === "") {
                alert("Address cannot be empty.");
                return false;
            }

            if (dob === "") {
                alert("Date of Birth cannot be empty.");
                return false;
            }

            if (religion === "Not Selected") {
                alert("Please select a religion.");
                return false;
            }

            if (username === "") {
                alert("Username cannot be empty.");
                return false;
            }

            if (password === "") {
                alert("Password cannot be empty.");
                return false;
            }

            if (password.length < 6) {
                alert("Password must be at least 6 characters long.");
                return false;
            }

            if (cpassword === "") {
                alert("Confirm Password cannot be empty.");
                return false;
            }

            if (password !== cpassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }
    </script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e04b1d;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #bf360c;
            font-size: 28px;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="text"], 
        input[type="email"],
        input[type="password"],
        input[type="date"],
        select {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input:focus, select:focus {
            border-color: #d84315;
            outline: none;
            box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: -10px;
            margin-bottom: 10px;
        }

        button {
            width: 100%;
            background-color: #d84315;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #d84315;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            color: #ff7043;
            text-decoration: underline;
        }
    </style>

</head>
<body>
<?php require 'header.php'; ?>

    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form method="post" action="../controller/sign-up-controller.php" novalidate autocomplete="off">
                    <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Registration Page</h1>
                    <b>Full Name:</b>
                    <input type="text" name="fullname" size="43px"placeholder="Enter Your Full Name">
                    <?php if (strlen($fullnameMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $fullnameMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Phone Number: </b><br>
                    <input type="text" name="phone" size="43px"placeholder="Enter Your Phone Number">
                    <?php if (strlen($phoneMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $phoneMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Email:</b><br>
                    <input type="email" name="email" size="43px"placeholder="Enter Your Email">
                    <?php if (strlen($emailMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $emailMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Address:</b>
                    <input type="text" name="address" size="43px"placeholder="Enter Your Address">
                    <?php if (strlen($addressMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $addressMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Date of Birth: </b> &nbsp;&nbsp;&nbsp;
                    <input type="date" name="dob" size="43px">
                    <?php if (strlen($dobMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $dobMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Religion: </b>&nbsp;&nbsp;&nbsp;
                    <select name="religion">
                        <option disabled selected hidden value="Not Selected">Choose Your Religion</option>
                        <option value="Islam">Islam</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Christian">Christian</option>
                    </select>
                    <?php if (strlen($religionMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $religionMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Username:</b> <br>
                    <input type="text" name="username" size="43px"placeholder="Enter Your Username">
                    <?php if (strlen($usernameMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $usernameMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Password:</b><br>
                    <input type="password" name="password" size="43px"placeholder="Enter Your Password">
                    <?php if (strlen($passwordMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $passwordMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Confirm Password:</b><br>
                    <input type="password" name="cpassword" size="43px"placeholder="Enter Your Confirm Password">
                    <?php if (strlen($cpasswordMsg) > 0) { ?>
                        <br><br>
                        <font color="red"><?= $cpasswordMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <button>Create Account</button>
                    <a href="sign-in.php">Go Back</a>
                </form>
            </td>
        </tr>
    </table>
    <?php require 'footer.php'; ?>
</body>
</html>
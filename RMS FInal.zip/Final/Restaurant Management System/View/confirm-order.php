<?php
session_start();
if (!isset($_SESSION['flag'])) {
    header('location:sign-in.php?err=signInFirst');
    exit();
}

require_once('../model/cart-model.php');

$id = $_COOKIE['id'] ?? null;
$totalBill = getTotalBill($id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Confirm your order by entering your password.">
    <title>Confirm Order</title>
    <script>
        function confirmOrder() {
            const password = document.getElementById('password').value.trim();

            if (password === "") {
                alert("Please enter your password to confirm the order.");
                return;
            }

            // Send AJAX request
            fetch('../controller/confirm-order-controller.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ password: password }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert(data.message);
                        window.location.href = 'confirm-order.php?success=confirmed';
                    } else {
                        alert(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                });
        }
    </script>
       <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e04b1d;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #bf360c;
            font-size: 28px;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input:focus {
            border-color: #d84315;
            outline: none;
            box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
        }

        .total-bill {
            font-weight: bold;
            color: #333;
            margin-bottom: 20px;
            display: block;
            text-align: center;
        }

        button {
            width: 100%;
            background-color: #d84315;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        button:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #d84315;
            text-decoration: none;
            font-size: 14px;
        }

        a:hover {
            color: #ff7043;
            text-decoration: underline;
        }
    </style>
</head>
<body>
<?php require 'header.php'; ?>
    <table width="35%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <h1>Confirm Order Page</h1>
                <b>Total Bill:</b> <?php echo htmlspecialchars($totalBill); ?>
                <br><br>
                <form id="confirmOrderForm" onsubmit="event.preventDefault(); confirmOrder();">
                    <b>Enter Your Password to Confirm Order:</b>
                    <br><br>
                    <input type="password" id="password" name="password" placeholder="Enter your password" style="width: 100%;">
                    <br><br>
                    <center>
                        <button type="submit">Confirm Order</button>
                        <a href="cart.php" style="margin-left: 10px;">Go Back</a>
                    </center>
                </form>
            </td>
        </tr>
    </table>
<?php require 'footer.php'; ?>
</body>
</html>

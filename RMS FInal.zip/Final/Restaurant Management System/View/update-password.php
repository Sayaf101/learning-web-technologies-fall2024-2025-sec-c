<?php
session_start();
if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
    require_once('../model/user-info-model.php');    
  
    $id = $_COOKIE['id'];
    $row = userInfo($id);

    $prevpasswordMsg = $passwordMsg = $cpasswordMsg = '';

    if (isset($_GET['err'])) {

    $err_msg = $_GET['err'];
    
    switch ($err_msg) {
        case 'prevpasswordEmpty': {
            $prevpasswordMsg = "Previous password can not be empty.";
            break;
        }
        case 'passwordEmpty': {
            $passwordMsg = "Password can not be empty.";
            break;
        }
        case 'cpasswordEmpty': {
            $cpasswordMsg = "Confirm password can not be empty.";
            break;
        }
        case 'passwordError': {
            $prevpasswordMsg = "Incorrect password.";
            break;
        }
        case 'invalid': {
            $passwordMsg = "Invalid password.";
            break;
        }
        case 'mismatch': {
            $cpasswordMsg = "Passwords do not match.";
            break;
        }
    }
    }

$success_msg = '';

if (isset($_GET['success'])) {

  $s_msg = $_GET['success'];

  switch ($s_msg) {
    case 'updated': {
        $success_msg = "Password successfully updated.";
        break;
      }
  }
}

?>  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password</title>
    <script>
        function validateForm() {
            const form = document.forms["updatePasswordForm"];
            const prevPassword = form["prevpassword"].value.trim();
            const newPassword = form["password"].value;
            const confirmPassword = form["cpassword"].value;

            if (prevPassword === "") {
                alert("Previous password cannot be empty.");
                return false;
            }

            if (newPassword === "") {
                alert("New password cannot be empty.");
                return false;
            }

            if (newPassword.length < 6) {
                alert("New password must be at least 6 characters long.");
                return false;
            }

            if (newPassword === prevPassword) {
                alert("New password cannot be the same as the previous password.");
                return false;
            }

            if (confirmPassword === "") {
                alert("Confirm password cannot be empty.");
                return false;
            }

            if (newPassword !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            return true;
        }
    </script>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #e04b1d;
        margin: 0;
        padding: 0;
        color: #333;
    }

    header {
        background-color: #d84315;
        color: white;
        padding: 10px 20px;
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    h1 {
        color: #d84315;
        font-family: 'Lucida Handwriting', cursive;
        font-size: 36px;
        text-align: center;
        margin: 20px 0;
    }

    table {
        margin: 50px auto;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    td {
        padding: 20px;
    }

    form {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    input[type="password"] {
        width: 90%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 16px;
    }

    input[type="password"]:focus {
        border-color: #d84315;
        outline: none;
        box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
    }

    button {
        background-color: #d84315;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    button:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    a {
        text-decoration: none;
        color: #d84315;
        font-size: 16px;
        margin-top: 15px;
        transition: color 0.3s ease;
    }

    a:hover {
        color: #ff7043;
    }

    font {
        display: block;
        margin-top: 10px;
        font-size: 14px;
    }

    font[align="center"] {
        text-align: center;
        display: block;
    }

    font[color="red"] {
        color: #d84315;
        font-weight: bold;
    }

    font[color="green"] {
        color: #4caf50;
        font-weight: bold;
</style>


</head>
<body>
<?php require 'header.php'; ?>
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
            <form method="post" action="../controller/update-password-controller.php" novalidate autocomplete="off" name="updatePasswordForm" onsubmit="return validateForm();">
                    <h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Update Password</h1>
                    <br><br>
                    <b>Previous Password:</b>
                    <input type="password" name="prevpassword" size="43px"placeholder="Enter Your Previous Password">
                    <?php if (strlen($prevpasswordMsg) > 0) { ?>
                        <br><br>
                        <font color="red" align="center"><?= $prevpasswordMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>New Password:</b>
                    <input type="password" name="password" size="43px"placeholder="Enter Your New Password">
                    <?php if (strlen($passwordMsg) > 0) { ?>
                        <br><br>
                        <font color="red" align="center"><?= $passwordMsg ?></font>
                    <?php } ?>
                    <br><br>
                    <b>Confirm New Password:</b>
                    <input type="password" name="cpassword" size="43px"placeholder="Enter Your Confirm Password">
                    <?php if (strlen($cpasswordMsg) > 0) { ?>
                        <br><br>
                        <font color="red" align="center"><?= $cpasswordMsg ?></font>
                    <?php } ?>
                    <?php if (strlen($success_msg) > 0) { ?>
                        <br><br>
                        <font color="green" align="center"><?= $success_msg ?></font>
                    <?php } ?>
                    <br><br>
                    <button name="submit">Change Password</button>
                    <a href="profile.php">Go Back</a>
                </form>
            </td>
        </tr>
    </table>
    <?php require 'footer.php'; ?>
</body>
</html>
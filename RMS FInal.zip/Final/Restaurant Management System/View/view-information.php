<?php
session_start();

if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
require_once('../model/user-info-model.php');

$id = $_COOKIE['id'];
$row = userInfo($id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Information</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Georgia', serif;
            background-color: #fff8e1;
            color: #3e2723;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #d84315;
            color: #ffffff;
            text-align: center;
            padding: 20px 0;
            font-size: 24px;
            font-family: 'Lucida Handwriting', cursive;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        header h1 {
            margin: 0;
        }

        h1 {
            color: #bf360c;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
            text-align: center;
            margin: 20px 0;
        }

        table {
            background-color: #ffe0b2;
            margin: 20px auto;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            border: 2px solid #d84315;
            width: 70%;
        }

        td {
            text-align: left;
            padding: 20px;
            font-size: 18px;
        }

        img {
            border-radius: 50%;
            border: 3px solid #ff7043;
            margin: 20px auto;
            display: block;
        }

        a {
            display: block;
            text-align: center;
            margin: 20px auto;
            width: 200px;
            padding: 10px;
            font-size: 18px;
            color: #ffffff;
            background-color: #d84315;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        a:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        footer {
            margin-top: 30px;
            font-size: 16px;
            font-family: 'Georgia', serif;
            text-align: center;
            padding: 10px 0;
            background-color: #d84315;
            color: #ffffff;
        }

        footer p {
            margin: 0;
        }
    </style>
</head>
<body>
<?php require 'header.php'; ?>
<h1>Your Information</h1>
<center>
    <?php echo "<img src=\"../{$row['ProfilePicture']}\" width=\"100px\">"; ?>
</center>
<table>
    <tr>
        <td>
            <?php
                echo "Full Name: {$row['Fullname']}<br><br>
                      Username: {$row['Username']}<br><br>
                      DOB: {$row['DOB']}<br><br>
                      Religion: {$row['Religion']}<br><br>
                      Phone: {$row['Phone']}<br><br>
                      Email: {$row['Email']}<br><br>
                      Address: {$row['Address']}<br>";
            ?>
        </td>
    </tr>
</table>
<a href="profile.php">Go Back</a>
<?php require 'footer.php'; ?>
</body>
</html>

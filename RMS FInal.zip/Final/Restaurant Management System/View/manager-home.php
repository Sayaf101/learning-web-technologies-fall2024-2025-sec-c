<?php

    session_start();
    if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signIn');

    require_once('../Model/user-info-model.php');

    $id = $_COOKIE['id'];
    $row=  userInfo($id);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Home</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
        color: #333;
    }

    header {
        background-color: #007bff;
        color: white;
        padding: 10px 20px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 1000;
    }

    header img {
        border-radius: 50%;
        height: 40px;
        width: 40px;
    }

    header a {
        color: white;
        text-decoration: none;
        font-weight: bold;
        margin-left: 15px;
        font-size: 16px;
    }

    header a:hover {
        text-decoration: underline;
    }

    main {
        padding: 20px;
        max-width: 600px;
        margin: 60px auto 20px; /* Added margin-top for spacing below sticky header */
        text-align: center;
    }

    main a {
        display: block;
        text-decoration: none;
        color: #007bff;
        font-size: 18px;
        margin: 10px 0;
        padding: 10px 15px;
        border: 1px solid #007bff;
        border-radius: 5px;
        text-align: center;
        transition: all 0.3s ease;
        background-color: #fff;
    }

    main a:hover {
        background-color: #007bff;
        color: white;
    }

    /* Styling for the links on the top */
    body > img {
        display: inline-block;
        border-radius: 50%;
    }

    body > a {
        font-size: 16px;
        font-weight: bold;
        color: #007bff;
        margin-left: 10px;
    }

    body > a:hover {
        text-decoration: underline;
    }

</style>

</head>
<body>
    <?php echo "<img src=\"../{$row['ProfilePicture']} \" width=\"40px\">"; ?> &nbsp;&nbsp; |  &nbsp;&nbsp; <a href="profile.php">Profile</a> &nbsp;&nbsp; |  &nbsp;&nbsp; <a href="../controller/logout-controller.php">Logout</a><br><br><br>
    <a href="view-all-delivery-person.php">View All Delivery Person</a>
    <br><br>
    <a href="recruit-delivery-person.php">Recruit Delivery Person</a>
    <br><br>
    <a href="overview.php">Overview</a>
    <br><br>
    <a href="update-stock.php">Update Stock</a>
    <br><br>
    <a href="approve-customer-review.php">Approve Customer Review</a>
</body>
</html>
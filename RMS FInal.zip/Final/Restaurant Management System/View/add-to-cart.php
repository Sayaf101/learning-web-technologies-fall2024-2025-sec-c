<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');
require_once('../model/menu-model.php'); 

$id = $_GET['id'];
$row = itemInfo($id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add To Cart</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #d84315;
        margin: 0;
        padding: 0;
        color: #333;
    }

    header {
        background-color: #e04b1d;
        color: white;
        padding: 10px 20px;
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    h3 {
        color: #333;
        font-size: 24px;
        margin-bottom: 15px;
    }

    table {
        margin: 50px auto;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        width: 35%;
    }

    td {
        padding: 20px;
        font-size: 18px;
        line-height: 1.6;
    }

    input[type="number"] {
        width: calc(100% - 20px);
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 5px;
        font-size: 16px;
    }

    input[type="number"]:focus {
        border-color: #d84315;
        outline: none;
        box-shadow: 0 0 5px rgba(216, 67, 21, 0.5);
    }

    button {
        background-color: #d84315;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 8px;
        font-size: 18px;
        cursor: pointer;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    button:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    a {
        display: block;
        text-align: center;
        margin: 20px auto;
        width: 200px;
        padding: 10px;
        font-size: 18px;
        color: #ffffff;
        background-color: #d84315;
        text-decoration: none;
        border-radius: 8px;
        font-weight: bold;
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    a:hover {
        background-color: #ff7043;
        transform: scale(1.05);
    }

    #message {
        text-align: center;
        margin-top: 20px;
        font-size: 16px;
    }

    #message span {
        font-weight: bold;
    }
</style>

</head>
<body>
    <?php require 'header.php'; ?>
    <table width="35%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <h3><?php echo $row['ItemName']; ?></h3>
                <b>Available Quantity : </b><?php echo $row['Stock']; ?>
                <br><br>
                <form id="addToCartForm">
                    <b>Enter Quantity :</b> 
                    <input type="number" name="quantity" id="quantity" placeholder="Enter Quantity" required>
                    <input type="hidden" name="id" value="<?php echo $row['ItemID']; ?>"> <!-- Hidden input for item ID -->
                    <br><br>
                    <center><button type="submit">Add To Cart</button></center>
                </form>
                <br>
                <div id="message"></div> <!-- Placeholder for feedback messages -->
            </td>
        </tr>
    </table>
    <a href="menu.php">Go Back</a>
    <?php require 'footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const form = document.getElementById('addToCartForm');
            const messageDiv = document.getElementById('message');

            form.addEventListener('submit', (event) => {
                event.preventDefault(); // Prevent default form submission

                const formData = new FormData(form); // Gather form data
                const itemID = formData.get('id'); // Get item ID

                // Send an AJAX request to the controller
                fetch(`../controller/add-to-cart-controller.php?id=${itemID}`, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json()) // Parse JSON response
                .then(data => {
                    if (data.status === 'success') {
                        messageDiv.innerHTML = `<span style="color: green;">${data.message}</span>`;
                    } else {
                        messageDiv.innerHTML = `<span style="color: red;">${data.message}</span>`;
                    }
                })
                .catch(error => {
                    messageDiv.innerHTML = `<span style="color: red;">An error occurred. Please try again later.</span>`;
                    console.error('Error:', error);
                });
            });
        });
    </script>
</body>
</html>

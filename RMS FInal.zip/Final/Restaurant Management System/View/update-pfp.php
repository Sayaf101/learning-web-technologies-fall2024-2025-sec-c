<?php
session_start();
if (!isset($_SESSION['flag'])) header('location:sign-in.php?err=signInFirst');

$error_msg = '';

if (isset($_GET['err'])) {
    $err_msg = $_GET['err'];
    switch ($err_msg) {
        case 'empty': $error_msg = "No file selected."; break;
        case 'failed': $error_msg = "Profile picture update failed."; break;
    }
}

$success_msg = '';

if (isset($_GET['success'])) {
    $s_msg = $_GET['success'];
    if ($s_msg === 'uploaded') $success_msg = "Profile picture successfully updated.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile Picture</title>
    <style>
        body {
            font-family: 'Georgia', serif;
            background-color: #e04b1d;
            color: #3e2723;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #d84315;
            color: #ffffff;
            text-align: center;
            padding: 20px 0;
            font-size: 24px;
            font-family: 'Lucida Handwriting', cursive;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
        }

        h1 {
            color: #bf360c;
            font-family: 'Lucida Handwriting', cursive;
            font-size: 36px;
            text-align: center;
            margin: 20px 0;
        }

        form {
            margin: 20px auto;
            padding: 20px;
            background-color: #ffe0b2;
            border-radius: 12px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
            width: 50%;
        }

        table {
            width: 100%;
        }

        td {
            text-align: center;
            padding: 20px;
        }

        input[type="file"] {
            font-size: 16px;
            margin: 10px 0;
        }

        input[type="submit"] {
            background-color: #d84315;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        a {
            text-decoration: none;
            color: white;
            background-color: #d84315;
            padding: 10px 20px;
            border-radius: 8px;
            font-size: 18px;
            display: inline-block;
            margin-top: 10px;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        a:hover {
            background-color: #ff7043;
            transform: scale(1.05);
        }

        .error {
            color: red;
            font-size: 14px;
        }

        .success {
            color: green;
            font-size: 14px;
        }
    </style>
</head>
<body>
<?php require 'header.php'; ?>
<center>
    <form action="../controller/update-pfp-controller.php" method="POST" novalidate autocomplete="off" enctype="multipart/form-data">
        <h1>Update Profile Picture</h1>
        <hr color="#bf360c" width="80%">
        <br>
        <table>
            <tr>
                <td>
                    <input type="file" name="myfile" accept=".png,.jpg,.jpeg">
                    <br><br>
                    <input type="submit" value="Upload Image" name="submit">
                    <br><br>
                    <?php if ($error_msg) echo "<div class='error'>{$error_msg}</div>"; ?>
                    <?php if ($success_msg) echo "<div class='success'>{$success_msg}</div>"; ?>
                    <br><br>
                    <a href="profile.php">Go Back</a>
                </td>
            </tr>
        </table>
    </form>
</center>
<?php require 'footer.php'; ?>
</body>
</html>

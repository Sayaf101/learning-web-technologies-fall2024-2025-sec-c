<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recruit Delivery Person</title>
    <style>
        .error {
            color: red;
            font-size: 0.9em;
        }
        .success {
            color: green;
            font-size: 0.9em;
        }
    </style>
    <script>
        function validateForm(event) {
            event.preventDefault(); 
            let isValid = true;

            
            const errors = document.querySelectorAll(".error");
            errors.forEach(error => error.innerHTML = "");

          
            const fullname = document.forms["deliveryPersonForm"]["fullname"].value.trim();
            const phone = document.forms["deliveryPersonForm"]["phone"].value.trim();
            const email = document.forms["deliveryPersonForm"]["email"].value.trim();
            const address = document.forms["deliveryPersonForm"]["address"].value.trim();
            const dob = document.forms["deliveryPersonForm"]["dob"].value;
            const religion = document.forms["deliveryPersonForm"]["religion"].value;
            const username = document.forms["deliveryPersonForm"]["username"].value.trim();
            const password = document.forms["deliveryPersonForm"]["password"].value;
            const cpassword = document.forms["deliveryPersonForm"]["cpassword"].value;

            if (fullname === "") {
                document.getElementById("fullnameError").innerHTML = "Fullname is required.";
                isValid = false;
            }

            if (!/^[0-9]{11}$/.test(phone)) {
                document.getElementById("phoneError").innerHTML = "Phone must be an 11-digit number.";
                isValid = false;
            }

            if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
                document.getElementById("emailError").innerHTML = "Email must be a valid email address.";
                isValid = false;
            }

            if (address === "") {
                document.getElementById("addressError").innerHTML = "Address is required.";
                isValid = false;
            }

            if (dob === "") {
                document.getElementById("dobError").innerHTML = "Date of Birth is required.";
                isValid = false;
            }

            if (religion === "Not Selected") {
                document.getElementById("religionError").innerHTML = "Please select a religion.";
                isValid = false;
            }

            if (username === "") {
                document.getElementById("usernameError").innerHTML = "Username is required.";
                isValid = false;
            }

            if (password.length < 8) {
                document.getElementById("passwordError").innerHTML = "Password must be at least 8 characters long.";
                isValid = false;
            }

            if (password !== cpassword) {
                document.getElementById("cpasswordError").innerHTML = "Passwords do not match.";
                isValid = false;
            }

            if (isValid) {
                document.forms["deliveryPersonForm"].submit(); 
            }
        }
    </script>
</head>
<body>
    <table width="27%" border="1" cellspacing="0" cellpadding="25" align="center">
        <tr>
            <td>
                <form name="deliveryPersonForm" method="post" action="../controller/recruit-delivery-person-controller.php" novalidate autocomplete="off" onsubmit="validateForm(event)">
                    <h1>Recruit Delivery Person</h1>

                    Fullname
                    <input type="text" name="fullname" size="43px">
                    <div id="fullnameError" class="error"></div>
                    <br><br>

                    Phone
                    <input type="text" name="phone" size="43px">
                    <div id="phoneError" class="error"></div>
                    <br><br>

                    Email
                    <input type="email" name="email" size="43px">
                    <div id="emailError" class="error"></div>
                    <br><br>

                    Address
                    <input type="text" name="address" size="43px">
                    <div id="addressError" class="error"></div>
                    <br><br>

                    Date Of Birth &nbsp;&nbsp;&nbsp;
                    <input type="date" name="dob" size="43px">
                    <div id="dobError" class="error"></div>
                    <br><br>

                    Religion &nbsp;&nbsp;&nbsp;
                    <select name="religion">
                        <option disabled selected hidden value="Not Selected">Choose Your Religion</option>
                        <option value="Islam">Islam</option>
                        <option value="Hindu">Hindu</option>
                        <option value="Christian">Christian</option>
                    </select>
                    <div id="religionError" class="error"></div>
                    <br><br>

                    Username
                    <input type="text" name="username" size="43px">
                    <div id="usernameError" class="error"></div>
                    <br><br>

                    Password
                    <input type="password" name="password" size="43px">
                    <div id="passwordError" class="error"></div>
                    <br><br>

                    Confirm Password
                    <input type="password" name="cpassword" size="43px">
                    <div id="cpasswordError" class="error"></div>
                    <br><br>

                    <?php if (!empty($success_msg)) { ?>
                        <span class="success" style="display:block; text-align:center;"><?= $success_msg ?></span>
                        <br><br>
                    <?php } ?>


                    <button>Create Account</button>
                </form>
            </td>
        </tr>
    </table>
</body>
</html>

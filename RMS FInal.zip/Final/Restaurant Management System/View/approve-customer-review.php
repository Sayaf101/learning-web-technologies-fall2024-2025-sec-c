<?php
session_start();
if(!isset($_SESSION['flag'])) header('location:sign-in.php?err=signIn');
    require_once('../Model/customer-review-model.php');
    require_once('../Model/user-info-model.php');
    require_once('../Model/menu-model.php');
  
    $result = getPendingReview();
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approve Customer Review</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }
        h1 {
            color: #007bff;
            font-size: 2em;
        }
        table {
            margin: auto;
            width: 85%;
            border-collapse: collapse;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        table th, table td {
            padding: 15px;
            text-align: center;
            border: 1px solid #ddd;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        table tr:nth-child(odd) {
            background-color: #ffffff;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        a {
            color: #007bff;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        center {
            margin-top: 20px;
            max-width: 900px;
        }
        td[colspan] {
            font-weight: bold;
            color: #666;
        }
    </style>
</head>
<body>
    <br><br>
    <center><h1>Pending Review List</h1>
    <?php 
           
            if(mysqli_num_rows($result)>0){
               echo" <table width=\"85%\" border=\"1\" cellspacing=\"0\" cellpadding=\"15\">
            <tr>
                <td>
                    Item Name
                </td>
                <td>
                    Customer Name
                </td>
                <td>
                    Review
                </td>
                <td>
                    Action
                </td>
                <hr width=auto><br>
            </tr>";
                while($w=mysqli_fetch_assoc($result)){
                    $reviewID = $w['ReviewID'];
                    $customerName = getUsernameByID($w['UserID']);
                    $itemName = getItemNameByID($w['ItemID']);
                    $review = $w['Review'];
                    echo "    
                    <tr><td>$itemName</td>
                    <td>$customerName</td>
                    <td>$review</td> 
                    <td><a href=\"../controller/approve-customer-review-controller.php?id={$reviewID}\">Approve Review</a></td>          
                    </tr>";
                }
            }else{
                echo"<tr><td align=\"center\">No Pending Review.</td></tr>";
            }
        ?>
        </table>
        </center>
</body>
</html>
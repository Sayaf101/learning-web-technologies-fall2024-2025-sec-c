<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Izakaya</title>
    <style>
        /* Center the header text */
        header {
            text-align: center;
            margin-top: 20px;
        }

        header h1 {
            font-size: 36px;
            font-weight: bold;
            color: #4CAF50;
        }

        header h3 {
            font-size: 24px;
            font-weight: bold;
            color: #666;
        }

        /* Styling for horizontal lines */
        hr {
            border: 0;
            height: 2px;
            background: #4CAF50;
            width: 80%;
            margin: 20px auto;
        }

        /* Add spacing around the header */
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome to Izakaya</h1>
        <h3><b>Where Good Food Meets Great Moments</b></h3>
    </header>
    <hr>
    <hr>
    <br><br><br>
</body>
</html>

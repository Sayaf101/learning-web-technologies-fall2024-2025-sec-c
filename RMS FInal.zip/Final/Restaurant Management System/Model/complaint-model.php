<?php

    require_once('database.php');

    $row;
    function sendComplaint($fullname, $complaint){

        $con = dbConnection();
        $sql = "insert into Complaint values('', '{$fullname}' ,'{$complaint}')";

        if(mysqli_query($con, $sql)) return true;
        else return false;
        
    }

?>
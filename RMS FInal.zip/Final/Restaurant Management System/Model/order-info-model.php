<?php

    require_once('database.php');

    $row;

    function createOrder($customerName, $deliveryManName, $address, $bill, $deliveryDate, $orderDate, $orderStatus){

        $con = dbConnection();
        $sql = "insert into OrderInfo values('', '{$customerName}' ,'{$deliveryManName}' ,'{$address}', {$bill}, '{$deliveryDate}', '{$orderDate}', '{$orderStatus}')";

        if(mysqli_query($con, $sql)) return true;
        else return false;
        
    }
    function getAllOrder(){

        $con = dbConnection();
        $sql = "select * from OrderInfo;";
    
        $result = mysqli_query($con,$sql);
        return $result;

    }

    function getOrderHistory($fullname){

        $con = dbConnection();
        $sql = "select * from OrderInfo where CustomerName = '{$fullname}' and OrderStatus = 'Completed';";
    
        $result = mysqli_query($con,$sql);
        return $result;

    }

?>
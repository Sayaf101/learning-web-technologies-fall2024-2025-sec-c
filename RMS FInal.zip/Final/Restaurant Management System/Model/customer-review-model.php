<?php

    require_once('database.php');

    $row;
    function getAllReview($id){

        $con = dbConnection();
        $sql="select * from CustomerReview where ItemID = '{$id}' and Status = 'Active'";

        $result=mysqli_query($con,$sql);
        return $result;
    }

    function postReview($itemID, $userID, $review, $status){

        $con = dbConnection();
        $sql = "insert into CustomerReview values('', '{$itemID}' ,'{$userID}' ,'{$review}', '{$status}')";

        if(mysqli_query($con, $sql)) return true;
        else return false;
        
    }

    function deleteReview($id){

        $con = dbConnection();
        $sql = "delete from CustomerReview where ReviewID = '$id'";
             
        if(mysqli_query($con,$sql)) return true;
        else return false; 

    }


?>